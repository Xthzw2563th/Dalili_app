class AppConstants {
  // تفضيلات المستخدم
  static const String prefIsDarkMode = 'is_dark_mode';
  static const String prefIsEnglish = 'is_english';
  static const String prefShowPrayerNotifications = 'show_prayer_notifications';
  static const String prefShowCountdownNotifications = 'show_countdown_notifications';
  static const String prefShowNewsNotifications = 'show_news_notifications';
  static const String prefUserLocation = 'user_location';
  static const String prefUserCity = 'user_city';
  static const String prefUserCountry = 'user_country';
  static const String prefIsPremium = 'is_premium';
  
  // مفاتيح API
  static const String weatherApiKey = 'YOUR_WEATHER_API_KEY';
  static const String newsApiKey = 'YOUR_NEWS_API_KEY';
  
  // روابط API
  static const String weatherApiBaseUrl = 'https://api.openweathermap.org/data/2.5';
  static const String newsApiBaseUrl = 'https://newsapi.org/v2';
  
  // تواريخ الرواتب والدعم
  static const Map<String, int> salaryDays = {
    'موظف': 27,
    'متقاعد': 20,
    'ضمان': 10,
    'حساب_المواطن': 10,
    'دعم_سكني': 15,
  };
  
  // الروابط المهمة
  static const Map<String, String> importantLinks = {
    'توكلنا': 'https://ta.sdaia.gov.sa',
    'مدرستي': 'https://schools.madrasati.sa',
    'أبشر': 'https://www.absher.sa',
    'صحتي': 'https://www.seha.sa',
    'نظام نور': 'https://noor.moe.gov.sa',
  };
  
  // المناسبات الهامة
  static const Map<String, String> importantEvents = {
    'اليوم الوطني': '09-23',
    'يوم التأسيس': '02-22',
    'عيد الفطر': 'متغير',
    'عيد الأضحى': 'متغير',
    'بداية العام الدراسي': '09-01',
    'نهاية العام الدراسي': '06-30',
  };
  
  // أسماء الأشهر الهجرية
  static const List<String> hijriMonths = [
    'محرم',
    'صفر',
    'ربيع الأول',
    'ربيع الثاني',
    'جمادى الأولى',
    'جمادى الآخرة',
    'رجب',
    'شعبان',
    'رمضان',
    'شوال',
    'ذو القعدة',
    'ذو الحجة',
  ];
  
  // أسماء الأشهر الميلادية بالعربية
  static const List<String> gregorianMonthsAr = [
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];
  
  // أسماء الأشهر الميلادية بالإنجليزية
  static const List<String> gregorianMonthsEn = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  
  // أسماء أيام الأسبوع بالعربية
  static const List<String> weekdaysAr = [
    'الأحد',
    'الإثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة',
    'السبت',
  ];
  
  // أسماء أيام الأسبوع بالإنجليزية
  static const List<String> weekdaysEn = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  
  // أسماء الصلوات
  static const List<String> prayerNames = [
    'الفجر',
    'الشروق',
    'الظهر',
    'العصر',
    'المغرب',
    'العشاء',
  ];
  
  // رسائل الخطأ
  static const String errorNoInternet = 'لا يوجد اتصال بالإنترنت';
  static const String errorServerFailure = 'حدث خطأ في الخادم';
  static const String errorCacheFailure = 'حدث خطأ في ذاكرة التخزين المؤقت';
  static const String errorLocationPermission = 'يرجى السماح بالوصول إلى موقعك';
  static const String errorLocationService = 'يرجى تفعيل خدمة الموقع';
  static const String errorGeneral = 'حدث خطأ ما';
  
  // رسائل النجاح
  static const String successSettingsUpdated = 'تم تحديث الإعدادات بنجاح';
  
  // رسائل أخرى
  static const String loadingMessage = 'جاري التحميل...';
  static const String noDataMessage = 'لا توجد بيانات';
  static const String premiumFeatureMessage = 'هذه الميزة متاحة للمشتركين فقط';
}

