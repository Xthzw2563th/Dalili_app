import 'package:dalili_app/core/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart';

class AppUtils {
  // تحويل التاريخ الميلادي إلى هجري
  static String convertToHijri(DateTime date, {bool showYear = true}) {
    final hijriDate = HijriCalendar.fromDate(date);
    if (showYear) {
      return '${hijriDate.hDay} ${AppConstants.hijriMonths[hijriDate.hMonth - 1]} ${hijriDate.hYear}';
    } else {
      return '${hijriDate.hDay} ${AppConstants.hijriMonths[hijriDate.hMonth - 1]}';
    }
  }

  // تحويل التاريخ الميلادي إلى نص بالعربية
  static String formatDateAr(DateTime date, {bool showYear = true}) {
    if (showYear) {
      return '${date.day} ${AppConstants.gregorianMonthsAr[date.month - 1]} ${date.year}';
    } else {
      return '${date.day} ${AppConstants.gregorianMonthsAr[date.month - 1]}';
    }
  }

  // تحويل التاريخ الميلادي إلى نص بالإنجليزية
  static String formatDateEn(DateTime date, {bool showYear = true}) {
    if (showYear) {
      return DateFormat('d MMMM yyyy').format(date);
    } else {
      return DateFormat('d MMMM').format(date);
    }
  }

  // الحصول على اسم اليوم بالعربية
  static String getDayNameAr(DateTime date) {
    return AppConstants.weekdaysAr[date.weekday % 7];
  }

  // الحصول على اسم اليوم بالإنجليزية
  static String getDayNameEn(DateTime date) {
    return DateFormat('EEEE').format(date);
  }

  // تنسيق الوقت (12 ساعة)
  static String formatTime12(TimeOfDay time) {
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.period == DayPeriod.am ? 'ص' : 'م';
    return '$hour:$minute $period';
  }

  // تنسيق الوقت (24 ساعة)
  static String formatTime24(TimeOfDay time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  // تحويل النص إلى كائن TimeOfDay
  static TimeOfDay stringToTimeOfDay(String time) {
    final parts = time.split(':');
    return TimeOfDay(
      hour: int.parse(parts[0]),
      minute: int.parse(parts[1]),
    );
  }

  // حساب الوقت المتبقي حتى تاريخ معين
  static Map<String, int> getRemainingTime(DateTime targetDate) {
    final now = DateTime.now();
    final difference = targetDate.difference(now);
    
    final days = difference.inDays;
    final hours = difference.inHours % 24;
    final minutes = difference.inMinutes % 60;
    final seconds = difference.inSeconds % 60;
    
    return {
      'days': days,
      'hours': hours,
      'minutes': minutes,
      'seconds': seconds,
    };
  }

  // تنسيق الوقت المتبقي كنص
  static String formatRemainingTime(Map<String, int> remainingTime, {bool showSeconds = true}) {
    final days = remainingTime['days'];
    final hours = remainingTime['hours'];
    final minutes = remainingTime['minutes'];
    final seconds = remainingTime['seconds'];
    
    String result = '';
    
    if (days! > 0) {
      result += '$days يوم ';
    }
    
    if (hours! > 0 || days > 0) {
      result += '$hours ساعة ';
    }
    
    if (minutes! > 0 || hours > 0 || days > 0) {
      result += '$minutes دقيقة ';
    }
    
    if (showSeconds && (seconds! > 0 || minutes > 0 || hours > 0 || days > 0)) {
      result += '$seconds ثانية';
    }
    
    return result.trim();
  }

  // حساب تاريخ الراتب القادم
  static DateTime getNextSalaryDate(String salaryType) {
    final now = DateTime.now();
    final salaryDay = AppConstants.salaryDays[salaryType] ?? 27;
    
    // إذا كان اليوم الحالي أكبر من يوم الراتب، فالراتب القادم في الشهر التالي
    if (now.day > salaryDay) {
      return DateTime(now.year, now.month + 1, salaryDay);
    } else {
      return DateTime(now.year, now.month, salaryDay);
    }
  }

  // تحويل درجة الحرارة من كلفن إلى مئوية
  static double kelvinToCelsius(double kelvin) {
    return kelvin - 273.15;
  }

  // تحويل سرعة الرياح من متر/ثانية إلى كم/ساعة
  static double mpsToKmh(double mps) {
    return mps * 3.6;
  }

  // الحصول على أيقونة الطقس المناسبة
  static String getWeatherIcon(String weatherCode) {
    switch (weatherCode) {
      case '01d':
        return 'assets/icons/weather/clear_day.png';
      case '01n':
        return 'assets/icons/weather/clear_night.png';
      case '02d':
        return 'assets/icons/weather/partly_cloudy_day.png';
      case '02n':
        return 'assets/icons/weather/partly_cloudy_night.png';
      case '03d':
      case '03n':
        return 'assets/icons/weather/cloudy.png';
      case '04d':
      case '04n':
        return 'assets/icons/weather/broken_clouds.png';
      case '09d':
      case '09n':
        return 'assets/icons/weather/shower_rain.png';
      case '10d':
        return 'assets/icons/weather/rain_day.png';
      case '10n':
        return 'assets/icons/weather/rain_night.png';
      case '11d':
      case '11n':
        return 'assets/icons/weather/thunderstorm.png';
      case '13d':
      case '13n':
        return 'assets/icons/weather/snow.png';
      case '50d':
      case '50n':
        return 'assets/icons/weather/mist.png';
      default:
        return 'assets/icons/weather/clear_day.png';
    }
  }

  // الحصول على وصف الطقس بالعربية
  static String getWeatherDescription(String englishDescription) {
    final Map<String, String> weatherDescriptions = {
      'clear sky': 'سماء صافية',
      'few clouds': 'قليل الغيوم',
      'scattered clouds': 'غيوم متفرقة',
      'broken clouds': 'غيوم متقطعة',
      'shower rain': 'زخات مطر',
      'rain': 'مطر',
      'thunderstorm': 'عاصفة رعدية',
      'snow': 'ثلج',
      'mist': 'ضباب',
      'overcast clouds': 'غائم',
      'light rain': 'مطر خفيف',
      'moderate rain': 'مطر معتدل',
      'heavy intensity rain': 'مطر شديد',
      'very heavy rain': 'مطر غزير جداً',
      'extreme rain': 'مطر غزير للغاية',
      'freezing rain': 'مطر متجمد',
      'light intensity shower rain': 'زخات مطر خفيفة',
      'heavy intensity shower rain': 'زخات مطر شديدة',
      'ragged shower rain': 'زخات مطر متقطعة',
    };
    
    return weatherDescriptions[englishDescription.toLowerCase()] ?? englishDescription;
  }

  // عرض رسالة سناك بار
  static void showSnackBar(BuildContext context, String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(10),
      ),
    );
  }

  // التحقق من صحة البريد الإلكتروني
  static bool isValidEmail(String email) {
    final emailRegExp = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegExp.hasMatch(email);
  }

  // التحقق من صحة رقم الهاتف
  static bool isValidPhone(String phone) {
    final phoneRegExp = RegExp(r'^(05)[0-9]{8}$');
    return phoneRegExp.hasMatch(phone);
  }

  // تحويل النص إلى حالة العنوان (أول حرف من كل كلمة كبير)
  static String toTitleCase(String text) {
    if (text.isEmpty) return text;
    
    return text.split(' ').map((word) {
      if (word.isEmpty) return word;
      return word[0].toUpperCase() + word.substring(1).toLowerCase();
    }).join(' ');
  }
}

