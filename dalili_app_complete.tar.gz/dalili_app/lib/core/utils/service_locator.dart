import 'package:dalili_app/features/calendar/data/repositories/calendar_repository_impl.dart';
import 'package:dalili_app/features/calendar/domain/repositories/calendar_repository.dart';
import 'package:dalili_app/features/calendar/domain/usecases/get_calendar_events.dart';
import 'package:dalili_app/features/calendar/presentation/bloc/calendar_bloc.dart';
import 'package:dalili_app/features/countdown/data/repositories/countdown_repository_impl.dart';
import 'package:dalili_app/features/countdown/domain/repositories/countdown_repository.dart';
import 'package:dalili_app/features/countdown/domain/usecases/get_countdown_dates.dart';
import 'package:dalili_app/features/countdown/presentation/bloc/countdown_bloc.dart';
import 'package:dalili_app/features/links/data/repositories/links_repository_impl.dart';
import 'package:dalili_app/features/links/domain/repositories/links_repository.dart';
import 'package:dalili_app/features/links/domain/usecases/get_important_links.dart';
import 'package:dalili_app/features/links/presentation/bloc/links_bloc.dart';
import 'package:dalili_app/features/news/data/repositories/news_repository_impl.dart';
import 'package:dalili_app/features/news/domain/repositories/news_repository.dart';
import 'package:dalili_app/features/news/domain/usecases/get_news.dart';
import 'package:dalili_app/features/news/presentation/bloc/news_bloc.dart';
import 'package:dalili_app/features/prayer_times/data/repositories/prayer_repository_impl.dart';
import 'package:dalili_app/features/prayer_times/domain/repositories/prayer_repository.dart';
import 'package:dalili_app/features/prayer_times/domain/usecases/get_prayer_times.dart';
import 'package:dalili_app/features/prayer_times/presentation/bloc/prayer_bloc.dart';
import 'package:dalili_app/features/qibla/data/repositories/qibla_repository_impl.dart';
import 'package:dalili_app/features/qibla/domain/repositories/qibla_repository.dart';
import 'package:dalili_app/features/qibla/domain/usecases/get_qibla_direction.dart';
import 'package:dalili_app/features/qibla/presentation/bloc/qibla_bloc.dart';
import 'package:dalili_app/features/settings/data/repositories/settings_repository_impl.dart';
import 'package:dalili_app/features/settings/domain/repositories/settings_repository.dart';
import 'package:dalili_app/features/settings/domain/usecases/get_settings.dart';
import 'package:dalili_app/features/settings/domain/usecases/update_settings.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:dalili_app/features/weather/data/repositories/weather_repository_impl.dart';
import 'package:dalili_app/features/weather/domain/repositories/weather_repository.dart';
import 'package:dalili_app/features/weather/domain/usecases/get_weather.dart';
import 'package:dalili_app/features/weather/presentation/bloc/weather_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'network/network_info.dart';

final sl = GetIt.instance;

Future<void> init() async {
  //! Features

  // Settings
  sl.registerFactory(
    () => SettingsProvider(
      getSettings: sl(),
      updateSettings: sl(),
    ),
  );

  // Prayer Times
  sl.registerFactory(
    () => PrayerBloc(
      getPrayerTimes: sl(),
    ),
  );

  // Qibla
  sl.registerFactory(
    () => QiblaBloc(
      getQiblaDirection: sl(),
    ),
  );

  // Calendar
  sl.registerFactory(
    () => CalendarBloc(
      getCalendarEvents: sl(),
    ),
  );

  // Countdown
  sl.registerFactory(
    () => CountdownBloc(
      getCountdownDates: sl(),
    ),
  );

  // Weather
  sl.registerFactory(
    () => WeatherBloc(
      getWeather: sl(),
    ),
  );

  // News
  sl.registerFactory(
    () => NewsBloc(
      getNews: sl(),
    ),
  );

  // Links
  sl.registerFactory(
    () => LinksBloc(
      getImportantLinks: sl(),
    ),
  );

  //! Use cases
  
  // Settings
  sl.registerLazySingleton(() => GetSettings(sl()));
  sl.registerLazySingleton(() => UpdateSettings(sl()));

  // Prayer Times
  sl.registerLazySingleton(() => GetPrayerTimes(sl()));

  // Qibla
  sl.registerLazySingleton(() => GetQiblaDirection(sl()));

  // Calendar
  sl.registerLazySingleton(() => GetCalendarEvents(sl()));

  // Countdown
  sl.registerLazySingleton(() => GetCountdownDates(sl()));

  // Weather
  sl.registerLazySingleton(() => GetWeather(sl()));

  // News
  sl.registerLazySingleton(() => GetNews(sl()));

  // Links
  sl.registerLazySingleton(() => GetImportantLinks(sl()));

  //! Repositories
  
  // Settings
  sl.registerLazySingleton<SettingsRepository>(
    () => SettingsRepositoryImpl(
      sharedPreferences: sl(),
    ),
  );

  // Prayer Times
  sl.registerLazySingleton<PrayerRepository>(
    () => PrayerRepositoryImpl(
      networkInfo: sl(),
      client: sl(),
    ),
  );

  // Qibla
  sl.registerLazySingleton<QiblaRepository>(
    () => QiblaRepositoryImpl(),
  );

  // Calendar
  sl.registerLazySingleton<CalendarRepository>(
    () => CalendarRepositoryImpl(
      networkInfo: sl(),
      client: sl(),
      sharedPreferences: sl(),
    ),
  );

  // Countdown
  sl.registerLazySingleton<CountdownRepository>(
    () => CountdownRepositoryImpl(
      sharedPreferences: sl(),
    ),
  );

  // Weather
  sl.registerLazySingleton<WeatherRepository>(
    () => WeatherRepositoryImpl(
      networkInfo: sl(),
      client: sl(),
    ),
  );

  // News
  sl.registerLazySingleton<NewsRepository>(
    () => NewsRepositoryImpl(
      networkInfo: sl(),
      client: sl(),
    ),
  );

  // Links
  sl.registerLazySingleton<LinksRepository>(
    () => LinksRepositoryImpl(),
  );

  //! Core
  sl.registerLazySingleton<NetworkInfo>(
    () => NetworkInfoImpl(sl()),
  );

  //! External
  final sharedPreferences = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sharedPreferences);
  sl.registerLazySingleton(() => http.Client());
  sl.registerLazySingleton(() => InternetConnectionChecker());
}

