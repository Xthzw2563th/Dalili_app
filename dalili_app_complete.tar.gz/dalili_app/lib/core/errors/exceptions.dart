class ServerException implements Exception {
  final String message;

  ServerException({this.message = 'حدث خطأ في الخادم'});
}

class CacheException implements Exception {
  final String message;

  CacheException({this.message = 'حدث خطأ في ذاكرة التخزين المؤقت'});
}

class LocationException implements Exception {
  final String message;

  LocationException({this.message = 'حدث خطأ في تحديد الموقع'});
}

class NetworkException implements Exception {
  final String message;

  NetworkException({this.message = 'لا يوجد اتصال بالإنترنت'});
}

class GeneralException implements Exception {
  final String message;

  GeneralException({this.message = 'حدث خطأ ما'});
}

