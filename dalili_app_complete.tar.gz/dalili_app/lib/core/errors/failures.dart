import 'package:dalili_app/core/constants/constants.dart';
import 'package:equatable/equatable.dart';

abstract class Failure extends Equatable {
  final String message;

  const Failure({required this.message});

  @override
  List<Object> get props => [message];
}

// فشل الاتصال بالإنترنت
class NetworkFailure extends Failure {
  const NetworkFailure() : super(message: AppConstants.errorNoInternet);
}

// فشل الخادم
class ServerFailure extends Failure {
  const ServerFailure() : super(message: AppConstants.errorServerFailure);
}

// فشل التخزين المؤقت
class CacheFailure extends Failure {
  const CacheFailure() : super(message: AppConstants.errorCacheFailure);
}

// فشل الحصول على الموقع
class LocationFailure extends Failure {
  const LocationFailure({required String message}) : super(message: message);
}

// فشل عام
class GeneralFailure extends Failure {
  const GeneralFailure({String message = AppConstants.errorGeneral}) : super(message: message);
}

