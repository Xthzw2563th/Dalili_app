import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/weather/domain/entities/weather.dart';
import 'package:dartz/dartz.dart';

abstract class WeatherRepository {
  Future<Either<Failure, Weather>> getWeather();
}

