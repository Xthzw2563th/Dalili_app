import 'package:equatable/equatable.dart';

class Weather extends Equatable {
  final String city;
  final double temperature;
  final double tempMin;
  final double tempMax;
  final int humidity;
  final double windSpeed;
  final String description;
  final String icon;
  final DateTime timestamp;

  const Weather({
    required this.city,
    required this.temperature,
    required this.tempMin,
    required this.tempMax,
    required this.humidity,
    required this.windSpeed,
    required this.description,
    required this.icon,
    required this.timestamp,
  });

  @override
  List<Object> get props => [
        city,
        temperature,
        tempMin,
        tempMax,
        humidity,
        windSpeed,
        description,
        icon,
        timestamp,
      ];
}

