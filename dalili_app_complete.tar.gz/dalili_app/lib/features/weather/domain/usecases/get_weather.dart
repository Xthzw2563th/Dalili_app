import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/weather/domain/entities/weather.dart';
import 'package:dalili_app/features/weather/domain/repositories/weather_repository.dart';
import 'package:dartz/dartz.dart';

class GetWeather {
  final WeatherRepository repository;

  GetWeather(this.repository);

  Future<Either<Failure, Weather>> call() async {
    return await repository.getWeather();
  }
}

