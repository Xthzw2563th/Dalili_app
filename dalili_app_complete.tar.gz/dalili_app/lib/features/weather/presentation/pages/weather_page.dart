import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/core/utils/app_utils.dart';
import 'package:dalili_app/features/weather/presentation/bloc/weather_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:lottie/lottie.dart';

class WeatherPage extends StatelessWidget {
  const WeatherPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'الطقس' : 'Weather'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              context.read<WeatherBloc>().add(GetWeatherEvent());
            },
          ),
        ],
      ),
      body: BlocBuilder<WeatherBloc, WeatherState>(
        builder: (context, state) {
          if (state is WeatherLoading) {
            return _buildLoadingState();
          } else if (state is WeatherLoaded) {
            return _buildLoadedState(context, state);
          } else if (state is WeatherError) {
            return _buildErrorState(context, state.message);
          } else {
            // حالة البداية، نطلب بيانات الطقس
            context.read<WeatherBloc>().add(GetWeatherEvent());
            return _buildLoadingState();
          }
        },
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 200.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.r),
              ),
            ),
            SizedBox(height: 24.h),
            Container(
              width: 200.w,
              height: 30.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4.r),
              ),
            ),
            SizedBox(height: 16.h),
            Expanded(
              child: ListView.builder(
                itemCount: 5,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.only(bottom: 16.h),
                    child: Container(
                      width: double.infinity,
                      height: 80.h,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.r),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, WeatherLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    final weather = state.weather;
    final temperature = AppUtils.kelvinToCelsius(weather.temperature).toStringAsFixed(1);
    final tempMin = AppUtils.kelvinToCelsius(weather.tempMin).toStringAsFixed(1);
    final tempMax = AppUtils.kelvinToCelsius(weather.tempMax).toStringAsFixed(1);
    final weatherDescription = isArabic
        ? AppUtils.getWeatherDescription(weather.description)
        : weather.description;
    
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(24.r),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _getWeatherGradient(weather.icon),
                ),
                borderRadius: BorderRadius.circular(16.r),
                boxShadow: [
                  BoxShadow(
                    color: _getWeatherGradient(weather.icon)[0].withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.location_on_rounded,
                        color: Colors.white,
                        size: 20.r,
                      ),
                      SizedBox(width: 4.w),
                      Text(
                        weather.city,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: Colors.white,
                            ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16.h),
                  _getWeatherAnimation(weather.icon),
                  SizedBox(height: 16.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        temperature,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 64.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '°C',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    weatherDescription,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Colors.white,
                        ),
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildWeatherInfoItem(
                        context,
                        icon: Icons.arrow_downward_rounded,
                        value: '$tempMin°C',
                        label: isArabic ? 'الصغرى' : 'Min',
                      ),
                      Container(
                        height: 30.h,
                        width: 1,
                        color: Colors.white.withOpacity(0.3),
                        margin: EdgeInsets.symmetric(horizontal: 16.w),
                      ),
                      _buildWeatherInfoItem(
                        context,
                        icon: Icons.arrow_upward_rounded,
                        value: '$tempMax°C',
                        label: isArabic ? 'العظمى' : 'Max',
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              isArabic ? 'تفاصيل الطقس' : 'Weather Details',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 16.h),
            _buildDetailCard(
              context,
              icon: Icons.water_drop_outlined,
              title: isArabic ? 'الرطوبة' : 'Humidity',
              value: '${weather.humidity}%',
              color: Colors.blue,
            ),
            SizedBox(height: 12.h),
            _buildDetailCard(
              context,
              icon: Icons.air,
              title: isArabic ? 'سرعة الرياح' : 'Wind Speed',
              value: '${AppUtils.mpsToKmh(weather.windSpeed).toStringAsFixed(1)} ${isArabic ? 'كم/س' : 'km/h'}',
              color: Colors.green,
            ),
            SizedBox(height: 12.h),
            _buildDetailCard(
              context,
              icon: Icons.access_time_rounded,
              title: isArabic ? 'آخر تحديث' : 'Last Update',
              value: _formatDateTime(weather.timestamp, isArabic),
              color: Colors.orange,
            ),
            SizedBox(height: 24.h),
            Center(
              child: Text(
                isArabic
                    ? 'يتم تحديث بيانات الطقس تلقائياً كل ساعة'
                    : 'Weather data is automatically updated every hour',
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeatherInfoItem(
    BuildContext context, {
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Column(
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 16.r,
            ),
            SizedBox(width: 4.w),
            Text(
              value,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                  ),
            ),
          ],
        ),
        SizedBox(height: 4.h),
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.white.withOpacity(0.8),
              ),
        ),
      ],
    );
  }

  Widget _buildDetailCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48.r,
            height: 48.r,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Icon(
              icon,
              color: color,
              size: 24.r,
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                SizedBox(height: 4.h),
                Text(
                  value,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.network(
              'https://assets3.lottiefiles.com/packages/lf20_jw3orjxj.json',
              width: 200.r,
              height: 200.r,
            ),
            SizedBox(height: 24.h),
            Text(
              message,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic
                  ? 'يرجى التأكد من تفعيل خدمة الموقع والسماح للتطبيق بالوصول إلى موقعك.'
                  : 'Please make sure location services are enabled and allow the app to access your location.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            ElevatedButton.icon(
              onPressed: () {
                context.read<WeatherBloc>().add(GetWeatherEvent());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                  horizontal: 24.w,
                  vertical: 12.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Color> _getWeatherGradient(String icon) {
    // تحديد التدرج اللوني بناءً على حالة الطقس
    switch (icon.substring(0, 2)) {
      case '01': // صافي
        return [
          const Color(0xFF47BFDF),
          const Color(0xFF4A91FF),
        ];
      case '02': // قليل الغيوم
        return [
          const Color(0xFF5374E7),
          const Color(0xFF77B9F5),
        ];
      case '03': // غائم جزئياً
      case '04': // غائم
        return [
          const Color(0xFF83A5E0),
          const Color(0xFFA9C1F5),
        ];
      case '09': // أمطار خفيفة
      case '10': // أمطار
        return [
          const Color(0xFF4A6FC0),
          const Color(0xFF6B98D4),
        ];
      case '11': // عاصفة رعدية
        return [
          const Color(0xFF363E59),
          const Color(0xFF4A6FC0),
        ];
      case '13': // ثلج
        return [
          const Color(0xFF7B98B2),
          const Color(0xFFB9D9E8),
        ];
      case '50': // ضباب
        return [
          const Color(0xFF7E8A97),
          const Color(0xFFABB8C3),
        ];
      default:
        return [
          const Color(0xFF47BFDF),
          const Color(0xFF4A91FF),
        ];
    }
  }

  Widget _getWeatherAnimation(String icon) {
    String animationUrl;
    
    switch (icon.substring(0, 2)) {
      case '01': // صافي
        animationUrl = icon.endsWith('d')
            ? 'https://assets9.lottiefiles.com/temp/lf20_XkF78Y.json'
            : 'https://assets9.lottiefiles.com/temp/lf20_Jj2Qzs.json';
        break;
      case '02': // قليل الغيوم
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_dgjK9i.json';
        break;
      case '03': // غائم جزئياً
      case '04': // غائم
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_kOfPKE.json';
        break;
      case '09': // أمطار خفيفة
      case '10': // أمطار
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_rpC1Rd.json';
        break;
      case '11': // عاصفة رعدية
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_EzPrWE.json';
        break;
      case '13': // ثلج
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_BSVgyt.json';
        break;
      case '50': // ضباب
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_HflU56.json';
        break;
      default:
        animationUrl = 'https://assets9.lottiefiles.com/temp/lf20_XkF78Y.json';
    }
    
    return Lottie.network(
      animationUrl,
      width: 120.r,
      height: 120.r,
    );
  }

  String _formatDateTime(DateTime dateTime, bool isArabic) {
    final hour = dateTime.hour.toString().padLeft(2, '0');
    final minute = dateTime.minute.toString().padLeft(2, '0');
    
    if (isArabic) {
      return '${AppUtils.formatDateAr(dateTime)} - $hour:$minute';
    } else {
      return '${AppUtils.formatDateEn(dateTime)} - $hour:$minute';
    }
  }
}

