import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/core/utils/app_utils.dart';
import 'package:dalili_app/features/weather/presentation/bloc/weather_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';

class WeatherWidget extends StatelessWidget {
  const WeatherWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isArabic ? 'الطقس' : 'Weather',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () {
                    context.read<WeatherBloc>().add(GetWeatherEvent());
                  },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            BlocBuilder<WeatherBloc, WeatherState>(
              builder: (context, state) {
                if (state is WeatherLoading) {
                  return _buildLoadingState();
                } else if (state is WeatherLoaded) {
                  return _buildLoadedState(context, state);
                } else if (state is WeatherError) {
                  return _buildErrorState(context, state.message);
                } else {
                  // حالة البداية، نطلب بيانات الطقس
                  context.read<WeatherBloc>().add(GetWeatherEvent());
                  return _buildLoadingState();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Container(
        width: double.infinity,
        height: 120.h,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, WeatherLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    final weather = state.weather;
    final temperature = AppUtils.kelvinToCelsius(weather.temperature).toStringAsFixed(1);
    final weatherDescription = isArabic
        ? AppUtils.getWeatherDescription(weather.description)
        : weather.description;
    
    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: _getWeatherGradient(weather.icon),
        ),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                weather.city,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              SizedBox(height: 4.h),
              Text(
                weatherDescription,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white,
                    ),
              ),
              SizedBox(height: 8.h),
              Row(
                children: [
                  Icon(
                    Icons.water_drop_outlined,
                    color: Colors.white,
                    size: 16.r,
                  ),
                  SizedBox(width: 4.w),
                  Text(
                    '${weather.humidity}%',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.white,
                        ),
                  ),
                  SizedBox(width: 12.w),
                  Icon(
                    Icons.air,
                    color: Colors.white,
                    size: 16.r,
                  ),
                  SizedBox(width: 4.w),
                  Text(
                    '${AppUtils.mpsToKmh(weather.windSpeed).toStringAsFixed(1)} ${isArabic ? 'كم/س' : 'km/h'}',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.white,
                        ),
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    temperature,
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  Text(
                    '°C',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Colors.white,
                        ),
                  ),
                ],
              ),
              SizedBox(height: 4.h),
              Text(
                '${weather.tempMin.toStringAsFixed(1)}° / ${weather.tempMax.toStringAsFixed(1)}°',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.white,
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: Theme.of(context).dividerTheme.color ?? Colors.grey.withOpacity(0.2),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.cloud_off_rounded,
            color: AppColors.error,
            size: 32.r,
          ),
          SizedBox(height: 8.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8.h),
          TextButton(
            onPressed: () {
              context.read<WeatherBloc>().add(GetWeatherEvent());
            },
            child: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
          ),
        ],
      ),
    );
  }

  List<Color> _getWeatherGradient(String icon) {
    // تحديد التدرج اللوني بناءً على حالة الطقس
    switch (icon.substring(0, 2)) {
      case '01': // صافي
        return [
          const Color(0xFF47BFDF),
          const Color(0xFF4A91FF),
        ];
      case '02': // قليل الغيوم
        return [
          const Color(0xFF5374E7),
          const Color(0xFF77B9F5),
        ];
      case '03': // غائم جزئياً
      case '04': // غائم
        return [
          const Color(0xFF83A5E0),
          const Color(0xFFA9C1F5),
        ];
      case '09': // أمطار خفيفة
      case '10': // أمطار
        return [
          const Color(0xFF4A6FC0),
          const Color(0xFF6B98D4),
        ];
      case '11': // عاصفة رعدية
        return [
          const Color(0xFF363E59),
          const Color(0xFF4A6FC0),
        ];
      case '13': // ثلج
        return [
          const Color(0xFF7B98B2),
          const Color(0xFFB9D9E8),
        ];
      case '50': // ضباب
        return [
          const Color(0xFF7E8A97),
          const Color(0xFFABB8C3),
        ];
      default:
        return [
          const Color(0xFF47BFDF),
          const Color(0xFF4A91FF),
        ];
    }
  }
}

