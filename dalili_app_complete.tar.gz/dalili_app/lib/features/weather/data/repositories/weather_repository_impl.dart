import 'dart:convert';

import 'package:dalili_app/core/constants/constants.dart';
import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/core/network/network_info.dart';
import 'package:dalili_app/features/weather/data/models/weather_model.dart';
import 'package:dalili_app/features/weather/domain/entities/weather.dart';
import 'package:dalili_app/features/weather/domain/repositories/weather_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class WeatherRepositoryImpl implements WeatherRepository {
  final NetworkInfo networkInfo;
  final http.Client client;

  WeatherRepositoryImpl({
    required this.networkInfo,
    required this.client,
  });

  @override
  Future<Either<Failure, Weather>> getWeather() async {
    if (await networkInfo.isConnected) {
      try {
        // الحصول على الموقع الحالي
        final position = await _determinePosition();
        
        // استخدام API للحصول على بيانات الطقس
        final url = '${AppConstants.weatherApiBaseUrl}/weather?lat=${position.latitude}&lon=${position.longitude}&appid=${AppConstants.weatherApiKey}';
        final response = await client.get(Uri.parse(url));
        
        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final weatherModel = WeatherModel.fromJson(data);
          
          return Right(weatherModel);
        } else {
          return Left(ServerFailure());
        }
      } on LocationException catch (e) {
        return Left(LocationFailure(message: e.message));
      } on ServerException {
        return Left(ServerFailure());
      } catch (e) {
        return Left(GeneralFailure(message: e.toString()));
      }
    } else {
      return Left(NetworkFailure());
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // التحقق مما إذا كانت خدمات الموقع ممكّنة
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw LocationException(message: 'يرجى تفعيل خدمة الموقع');
    }

    // التحقق من إذن الموقع
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك');
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك من إعدادات الجهاز');
    }

    // الحصول على الموقع الحالي
    return await Geolocator.getCurrentPosition();
  }
}

