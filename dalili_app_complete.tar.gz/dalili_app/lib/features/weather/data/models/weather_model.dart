import 'package:dalili_app/features/weather/domain/entities/weather.dart';

class WeatherModel extends Weather {
  const WeatherModel({
    required String city,
    required double temperature,
    required double tempMin,
    required double tempMax,
    required int humidity,
    required double windSpeed,
    required String description,
    required String icon,
    required DateTime timestamp,
  }) : super(
          city: city,
          temperature: temperature,
          tempMin: tempMin,
          tempMax: tempMax,
          humidity: humidity,
          windSpeed: windSpeed,
          description: description,
          icon: icon,
          timestamp: timestamp,
        );

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    final weather = json['weather'][0];
    final main = json['main'];
    final wind = json['wind'];
    
    return WeatherModel(
      city: json['name'],
      temperature: main['temp'].toDouble(),
      tempMin: main['temp_min'].toDouble(),
      tempMax: main['temp_max'].toDouble(),
      humidity: main['humidity'],
      windSpeed: wind['speed'].toDouble(),
      description: weather['description'],
      icon: weather['icon'],
      timestamp: DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'city': city,
      'temperature': temperature,
      'temp_min': tempMin,
      'temp_max': tempMax,
      'humidity': humidity,
      'wind_speed': windSpeed,
      'description': description,
      'icon': icon,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}

