import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/core/network/network_info.dart';
import 'package:dalili_app/features/qibla/data/models/qibla_info_model.dart';
import 'package:dalili_app/features/qibla/domain/entities/qibla_info.dart';
import 'package:dalili_app/features/qibla/domain/repositories/qibla_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_qiblah/flutter_qiblah.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

class QiblaRepositoryImpl implements QiblaRepository {
  final NetworkInfo networkInfo;

  QiblaRepositoryImpl({
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, QiblaInfo>> getQiblaDirection() async {
    try {
      // التحقق من توفر البوصلة
      final compassAvailable = await FlutterQiblah.androidDeviceSensorSupport();
      
      if (compassAvailable != true) {
        return Left(DeviceFailure(
          message: 'البوصلة غير متوفرة على جهازك',
        ));
      }
      
      // الحصول على الموقع الحالي
      final position = await _determinePosition();
      
      // الحصول على اتجاه القبلة
      final qiblaDirection = await _calculateQiblaDirection(
        position.latitude,
        position.longitude,
      );
      
      // الحصول على اسم الموقع الحالي
      final currentLocation = await _getLocationName(
        position.latitude,
        position.longitude,
      );
      
      final qiblaInfo = QiblaInfoModel(
        qiblaDirection: qiblaDirection,
        currentLocation: currentLocation,
      );
      
      return Right(qiblaInfo);
    } on LocationException catch (e) {
      return Left(LocationFailure(message: e.message));
    } catch (e) {
      return Left(GeneralFailure(message: e.toString()));
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // التحقق مما إذا كانت خدمات الموقع ممكّنة
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw LocationException(message: 'يرجى تفعيل خدمة الموقع');
    }

    // التحقق من إذن الموقع
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك');
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك من إعدادات الجهاز');
    }

    // الحصول على الموقع الحالي
    return await Geolocator.getCurrentPosition();
  }

  Future<double> _calculateQiblaDirection(double latitude, double longitude) async {
    // إحداثيات الكعبة المشرفة
    const kaabaLatitude = 21.422487;
    const kaabaLongitude = 39.826206;
    
    // حساب اتجاه القبلة باستخدام مكتبة FlutterQiblah
    final qiblaData = await FlutterQiblah.qiblaDirection;
    return qiblaData.qiblah;
  }

  Future<String> _getLocationName(double latitude, double longitude) async {
    try {
      if (await networkInfo.isConnected) {
        final placemarks = await placemarkFromCoordinates(latitude, longitude);
        
        if (placemarks.isNotEmpty) {
          final placemark = placemarks.first;
          
          // تكوين اسم الموقع
          final List<String> locationParts = [];
          
          if (placemark.locality != null && placemark.locality!.isNotEmpty) {
            locationParts.add(placemark.locality!);
          }
          
          if (placemark.administrativeArea != null && placemark.administrativeArea!.isNotEmpty) {
            locationParts.add(placemark.administrativeArea!);
          }
          
          if (placemark.country != null && placemark.country!.isNotEmpty) {
            locationParts.add(placemark.country!);
          }
          
          return locationParts.join(', ');
        }
      }
      
      // في حالة عدم توفر الإنترنت أو عدم العثور على اسم الموقع
      return 'موقعك الحالي';
    } catch (e) {
      return 'موقعك الحالي';
    }
  }
}

