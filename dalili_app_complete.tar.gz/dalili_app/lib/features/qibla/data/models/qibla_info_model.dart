import 'package:dalili_app/features/qibla/domain/entities/qibla_info.dart';

class QiblaInfoModel extends QiblaInfo {
  const QiblaInfoModel({
    required double qiblaDirection,
    required String currentLocation,
  }) : super(
          qiblaDirection: qiblaDirection,
          currentLocation: currentLocation,
        );

  factory QiblaInfoModel.fromJson(Map<String, dynamic> json) {
    return QiblaInfoModel(
      qiblaDirection: json['qibla_direction'],
      currentLocation: json['current_location'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'qibla_direction': qiblaDirection,
      'current_location': currentLocation,
    };
  }
}

