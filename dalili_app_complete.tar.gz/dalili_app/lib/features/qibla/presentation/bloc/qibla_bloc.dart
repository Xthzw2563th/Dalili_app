import 'package:dalili_app/features/qibla/domain/usecases/get_qibla_direction.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// الأحداث
abstract class QiblaEvent extends Equatable {
  const QiblaEvent();

  @override
  List<Object> get props => [];
}

class GetQiblaDirectionEvent extends QiblaEvent {}

// الحالات
abstract class QiblaState extends Equatable {
  const QiblaState();

  @override
  List<Object> get props => [];
}

class QiblaInitial extends QiblaState {}

class QiblaLoading extends QiblaState {}

class QiblaLoaded extends QiblaState {
  final double qiblaDirection;
  final String currentLocation;

  const QiblaLoaded({
    required this.qiblaDirection,
    required this.currentLocation,
  });

  @override
  List<Object> get props => [qiblaDirection, currentLocation];
}

class QiblaError extends QiblaState {
  final String message;

  const QiblaError({required this.message});

  @override
  List<Object> get props => [message];
}

// بلوك
class QiblaBloc extends Bloc<QiblaEvent, QiblaState> {
  final GetQiblaDirection getQiblaDirection;

  QiblaBloc({
    required this.getQiblaDirection,
  }) : super(QiblaInitial()) {
    on<GetQiblaDirectionEvent>(_onGetQiblaDirection);
  }

  Future<void> _onGetQiblaDirection(
    GetQiblaDirectionEvent event,
    Emitter<QiblaState> emit,
  ) async {
    emit(QiblaLoading());
    
    final result = await getQiblaDirection();
    
    result.fold(
      (failure) => emit(QiblaError(message: failure.message)),
      (qiblaInfo) => emit(QiblaLoaded(
        qiblaDirection: qiblaInfo.qiblaDirection,
        currentLocation: qiblaInfo.currentLocation,
      )),
    );
  }
}

