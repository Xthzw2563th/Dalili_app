import 'dart:math' as math;

import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/qibla/presentation/bloc/qibla_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:flutter_qiblah/flutter_qiblah.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:lottie/lottie.dart';

class QiblaPage extends StatefulWidget {
  const QiblaPage({Key? key}) : super(key: key);

  @override
  State<QiblaPage> createState() => _QiblaPageState();
}

class _QiblaPageState extends State<QiblaPage> {
  @override
  void initState() {
    super.initState();
    context.read<QiblaBloc>().add(GetQiblaDirectionEvent());
  }
  
  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'اتجاه القبلة' : 'Qibla Direction'),
        centerTitle: true,
      ),
      body: BlocBuilder<QiblaBloc, QiblaState>(
        builder: (context, state) {
          if (state is QiblaLoading) {
            return _buildLoadingState(context);
          } else if (state is QiblaLoaded) {
            return _buildLoadedState(context, state);
          } else if (state is QiblaError) {
            return _buildErrorState(context, state.message);
          } else {
            // حالة البداية، نطلب اتجاه القبلة
            context.read<QiblaBloc>().add(GetQiblaDirectionEvent());
            return _buildLoadingState(context);
          }
        },
      ),
    );
  }

  Widget _buildLoadingState(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.network(
            'https://assets10.lottiefiles.com/packages/lf20_jbrw3hcz.json',
            width: 200.r,
            height: 200.r,
          ),
          SizedBox(height: 24.h),
          Text(
            isArabic ? 'جاري تحديد اتجاه القبلة...' : 'Determining Qibla direction...',
            style: Theme.of(context).textTheme.titleLarge,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, QiblaLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return StreamBuilder<CompassEvent>(
      stream: FlutterCompass.events,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _buildErrorState(
            context,
            isArabic
                ? 'حدث خطأ في البوصلة. يرجى التأكد من أن جهازك يدعم البوصلة.'
                : 'Compass error. Please make sure your device supports compass.',
          );
        }
        
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _buildLoadingState(context);
        }
        
        double? direction = snapshot.data?.heading;
        
        // إذا كانت البوصلة غير متوفرة
        if (direction == null) {
          return _buildErrorState(
            context,
            isArabic
                ? 'البوصلة غير متوفرة على جهازك.'
                : 'Compass is not available on your device.',
          );
        }
        
        double qiblaDirection = state.qiblaDirection;
        double needleDirection = direction - qiblaDirection;
        
        return Column(
          children: [
            SizedBox(height: 24.h),
            Text(
              isArabic ? 'اتجاه القبلة' : 'Qibla Direction',
              style: Theme.of(context).textTheme.headlineMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8.h),
            Text(
              isArabic
                  ? 'قم بتوجيه السهم نحو الكعبة المشرفة'
                  : 'Point the arrow towards the Kaaba',
              style: Theme.of(context).textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40.h),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 300.r,
                  height: 300.r,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.royalBlue.withOpacity(0.1),
                    border: Border.all(
                      color: AppColors.royalBlue.withOpacity(0.3),
                      width: 2.r,
                    ),
                  ),
                  child: CustomPaint(
                    painter: CompassPainter(
                      direction: direction,
                      isArabic: isArabic,
                    ),
                  ),
                ),
                Transform.rotate(
                  angle: (needleDirection * (math.pi / 180) * -1),
                  child: Image.network(
                    'https://cdn-icons-png.flaticon.com/512/5776/5776762.png',
                    width: 150.r,
                    height: 150.r,
                  ),
                ),
                Container(
                  width: 20.r,
                  height: 20.r,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.royalBlue,
                  ),
                ),
              ],
            ),
            SizedBox(height: 40.h),
            Container(
              padding: EdgeInsets.all(16.r),
              margin: EdgeInsets.symmetric(horizontal: 24.w),
              decoration: BoxDecoration(
                color: Theme.of(context).cardTheme.color,
                borderRadius: BorderRadius.circular(16.r),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildInfoRow(
                    context,
                    icon: Icons.location_on_rounded,
                    title: isArabic ? 'موقعك الحالي' : 'Your Location',
                    value: state.currentLocation,
                  ),
                  SizedBox(height: 12.h),
                  _buildInfoRow(
                    context,
                    icon: Icons.explore_rounded,
                    title: isArabic ? 'اتجاه القبلة' : 'Qibla Direction',
                    value: '${qiblaDirection.toStringAsFixed(1)}°',
                  ),
                  SizedBox(height: 12.h),
                  _buildInfoRow(
                    context,
                    icon: Icons.compass_calibration_rounded,
                    title: isArabic ? 'اتجاه البوصلة' : 'Compass Direction',
                    value: '${direction.toStringAsFixed(1)}°',
                  ),
                ],
              ),
            ),
            SizedBox(height: 24.h),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Text(
                isArabic
                    ? 'قم بمعايرة البوصلة عن طريق تحريك هاتفك بشكل دائري قبل الاستخدام للحصول على أفضل النتائج.'
                    : 'Calibrate your compass by moving your phone in a figure-8 motion before use for best results.',
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildInfoRow(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      children: [
        Container(
          width: 40.r,
          height: 40.r,
          decoration: BoxDecoration(
            color: AppColors.royalBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(
            icon,
            color: AppColors.royalBlue,
            size: 20.r,
          ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(height: 2.h),
              Text(
                value,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.network(
              'https://assets3.lottiefiles.com/packages/lf20_jbrw3hcz.json',
              width: 200.r,
              height: 200.r,
            ),
            SizedBox(height: 24.h),
            Text(
              message,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic
                  ? 'يرجى التأكد من تفعيل خدمة الموقع والسماح للتطبيق بالوصول إلى موقعك.'
                  : 'Please make sure location services are enabled and allow the app to access your location.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            ElevatedButton.icon(
              onPressed: () {
                context.read<QiblaBloc>().add(GetQiblaDirectionEvent());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                  horizontal: 24.w,
                  vertical: 12.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CompassPainter extends CustomPainter {
  final double direction;
  final bool isArabic;

  CompassPainter({required this.direction, required this.isArabic});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    
    // رسم الدائرة الخارجية
    final outerCirclePaint = Paint()
      ..color = Colors.grey.withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    
    canvas.drawCircle(center, radius - 10, outerCirclePaint);
    
    // رسم علامات الاتجاهات
    final markerPaint = Paint()
      ..color = Colors.grey
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    
    final textPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    
    // رسم الاتجاهات الرئيسية
    final directions = isArabic
        ? ['ش', 'ش ش', 'ش غ', 'غ', 'ج غ', 'ج', 'ج ش', 'ش']
        : ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45 - direction) * (math.pi / 180);
      final dx = center.dx + (radius - 30) * math.sin(angle);
      final dy = center.dy - (radius - 30) * math.cos(angle);
      
      // رسم علامة الاتجاه
      canvas.drawLine(
        Offset(dx, dy),
        Offset(
          dx - 15 * math.sin(angle),
          dy + 15 * math.cos(angle),
        ),
        markerPaint,
      );
      
      // كتابة اسم الاتجاه
      textPainter.text = TextSpan(
        text: directions[i],
        style: TextStyle(
          color: i == 0 ? AppColors.royalBlue : Colors.grey,
          fontSize: 14,
          fontWeight: i == 0 ? FontWeight.bold : FontWeight.normal,
        ),
      );
      
      textPainter.layout();
      
      textPainter.paint(
        canvas,
        Offset(
          dx - textPainter.width / 2,
          dy - textPainter.height / 2 - 20,
        ),
      );
    }
    
    // رسم علامات الدرجات
    for (int i = 0; i < 360; i += 15) {
      final angle = (i - direction) * (math.pi / 180);
      final outerX = center.dx + (radius - 10) * math.sin(angle);
      final outerY = center.dy - (radius - 10) * math.cos(angle);
      
      final innerX = center.dx + (radius - (i % 45 == 0 ? 25 : 15)) * math.sin(angle);
      final innerY = center.dy - (radius - (i % 45 == 0 ? 25 : 15)) * math.cos(angle);
      
      canvas.drawLine(
        Offset(outerX, outerY),
        Offset(innerX, innerY),
        markerPaint,
      );
      
      // كتابة الدرجات الرئيسية
      if (i % 90 == 0) {
        textPainter.text = TextSpan(
          text: '$i°',
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        );
        
        textPainter.layout();
        
        textPainter.paint(
          canvas,
          Offset(
            innerX - textPainter.width / 2,
            innerY - textPainter.height / 2 - 5,
          ),
        );
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

