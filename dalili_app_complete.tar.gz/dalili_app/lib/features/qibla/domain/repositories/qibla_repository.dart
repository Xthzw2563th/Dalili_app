import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/qibla/domain/entities/qibla_info.dart';
import 'package:dartz/dartz.dart';

abstract class QiblaRepository {
  Future<Either<Failure, QiblaInfo>> getQiblaDirection();
}

