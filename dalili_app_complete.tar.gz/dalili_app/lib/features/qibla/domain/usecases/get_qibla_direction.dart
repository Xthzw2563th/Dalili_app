import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/qibla/domain/entities/qibla_info.dart';
import 'package:dalili_app/features/qibla/domain/repositories/qibla_repository.dart';
import 'package:dartz/dartz.dart';

class GetQiblaDirection {
  final QiblaRepository repository;

  GetQiblaDirection(this.repository);

  Future<Either<Failure, QiblaInfo>> call() async {
    return await repository.getQiblaDirection();
  }
}

