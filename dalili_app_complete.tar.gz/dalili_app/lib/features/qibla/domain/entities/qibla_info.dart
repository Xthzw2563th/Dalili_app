import 'package:equatable/equatable.dart';

class QiblaInfo extends Equatable {
  final double qiblaDirection;
  final String currentLocation;

  const QiblaInfo({
    required this.qiblaDirection,
    required this.currentLocation,
  });

  @override
  List<Object> get props => [qiblaDirection, currentLocation];
}

