import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/prayer_times/domain/entities/prayer_times.dart';
import 'package:dalili_app/features/prayer_times/domain/repositories/prayer_repository.dart';
import 'package:dartz/dartz.dart';

class GetPrayerTimes {
  final PrayerRepository repository;

  GetPrayerTimes(this.repository);

  Future<Either<Failure, PrayerTimes>> call() async {
    return await repository.getPrayerTimes();
  }
}

