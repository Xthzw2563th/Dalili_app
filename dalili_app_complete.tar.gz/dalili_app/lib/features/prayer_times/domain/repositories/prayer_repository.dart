import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/prayer_times/domain/entities/prayer_times.dart';
import 'package:dartz/dartz.dart';

abstract class PrayerRepository {
  Future<Either<Failure, PrayerTimes>> getPrayerTimes();
}

