import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/prayer_times/presentation/bloc/prayer_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:lottie/lottie.dart';

class PrayerTimesPage extends StatelessWidget {
  const PrayerTimesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'أوقات الصلاة' : 'Prayer Times'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              context.read<PrayerBloc>().add(GetPrayerTimesEvent());
            },
          ),
        ],
      ),
      body: BlocBuilder<PrayerBloc, PrayerState>(
        builder: (context, state) {
          if (state is PrayerLoading) {
            return _buildLoadingState();
          } else if (state is PrayerLoaded) {
            return _buildLoadedState(context, state);
          } else if (state is PrayerError) {
            return _buildErrorState(context, state.message);
          } else {
            // حالة البداية، نطلب أوقات الصلاة
            context.read<PrayerBloc>().add(GetPrayerTimesEvent());
            return _buildLoadingState();
          }
        },
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 200.w,
              height: 30.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4.r),
              ),
            ),
            SizedBox(height: 16.h),
            Container(
              width: double.infinity,
              height: 100.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16.r),
              ),
            ),
            SizedBox(height: 24.h),
            Container(
              width: 150.w,
              height: 24.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4.r),
              ),
            ),
            SizedBox(height: 16.h),
            Expanded(
              child: ListView.builder(
                itemCount: 6,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.only(bottom: 16.h),
                    child: Container(
                      width: double.infinity,
                      height: 80.h,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.r),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, PrayerLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    final prayerNames = [
      isArabic ? 'الفجر' : 'Fajr',
      isArabic ? 'الشروق' : 'Sunrise',
      isArabic ? 'الظهر' : 'Dhuhr',
      isArabic ? 'العصر' : 'Asr',
      isArabic ? 'المغرب' : 'Maghrib',
      isArabic ? 'العشاء' : 'Isha',
    ];
    
    final prayerTimes = [
      state.prayerTimes.fajr,
      state.prayerTimes.sunrise,
      state.prayerTimes.dhuhr,
      state.prayerTimes.asr,
      state.prayerTimes.maghrib,
      state.prayerTimes.isha,
    ];
    
    final now = DateTime.now();
    int nextPrayerIndex = 0;
    
    // تحديد الصلاة التالية
    for (int i = 0; i < prayerTimes.length; i++) {
      if (prayerTimes[i].isAfter(now)) {
        nextPrayerIndex = i;
        break;
      }
    }
    
    // حساب الوقت المتبقي للصلاة التالية
    final remainingTime = prayerTimes[nextPrayerIndex].difference(now);
    final hours = remainingTime.inHours;
    final minutes = remainingTime.inMinutes % 60;
    final seconds = remainingTime.inSeconds % 60;
    
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isArabic
                  ? 'أوقات الصلاة في ${state.prayerTimes.city}'
                  : 'Prayer Times in ${state.prayerTimes.city}',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(height: 8.h),
            Text(
              isArabic
                  ? 'تاريخ اليوم: ${state.prayerTimes.date}'
                  : 'Today: ${state.prayerTimes.date}',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            SizedBox(height: 24.h),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppColors.royalBlue,
                    AppColors.turquoise,
                  ],
                ),
                borderRadius: BorderRadius.circular(16.r),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.royalBlue.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isArabic ? 'الصلاة التالية' : 'Next Prayer',
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                  color: Colors.white.withOpacity(0.8),
                                ),
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            prayerNames[nextPrayerIndex],
                            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            _formatTime(prayerTimes[nextPrayerIndex]),
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  color: Colors.white,
                                ),
                          ),
                        ],
                      ),
                      Container(
                        padding: EdgeInsets.all(16.r),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                        child: Column(
                          children: [
                            Text(
                              isArabic ? 'متبقي' : 'Remaining',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Colors.white.withOpacity(0.8),
                                  ),
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              '$hours:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}',
                              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              isArabic ? 'جميع أوقات الصلاة اليوم' : 'All Prayer Times Today',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 16.h),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: prayerTimes.length,
              itemBuilder: (context, index) {
                final isNextPrayer = index == nextPrayerIndex;
                final isPassed = prayerTimes[index].isBefore(now);
                
                return Padding(
                  padding: EdgeInsets.only(bottom: 16.h),
                  child: Container(
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: isNextPrayer
                          ? AppColors.royalBlue.withOpacity(0.1)
                          : Theme.of(context).cardTheme.color,
                      borderRadius: BorderRadius.circular(16.r),
                      border: isNextPrayer
                          ? Border.all(color: AppColors.royalBlue)
                          : null,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 48.r,
                              height: 48.r,
                              decoration: BoxDecoration(
                                color: isNextPrayer
                                    ? AppColors.royalBlue
                                    : AppColors.lightBackground,
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                              child: Icon(
                                _getPrayerIcon(index),
                                color: isNextPrayer
                                    ? Colors.white
                                    : AppColors.lightTextSecondary,
                                size: 24.r,
                              ),
                            ),
                            SizedBox(width: 16.w),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  prayerNames[index],
                                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                        color: isNextPrayer
                                            ? AppColors.royalBlue
                                            : null,
                                        fontWeight: isNextPrayer
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  _formatTime(prayerTimes[index]),
                                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                        color: isNextPrayer
                                            ? AppColors.royalBlue
                                            : null,
                                      ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        if (isPassed)
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 12.w,
                              vertical: 6.h,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.grey.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                            child: Text(
                              isArabic ? 'انتهى' : 'Passed',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          )
                        else if (isNextPrayer)
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 12.w,
                              vertical: 6.h,
                            ),
                            decoration: BoxDecoration(
                              color: AppColors.royalBlue.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                            child: Text(
                              isArabic ? 'التالية' : 'Next',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AppColors.royalBlue,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.network(
              'https://assets10.lottiefiles.com/packages/lf20_tl52xzvn.json',
              width: 200.r,
              height: 200.r,
            ),
            SizedBox(height: 24.h),
            Text(
              message,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic
                  ? 'يرجى التأكد من تفعيل خدمة الموقع والسماح للتطبيق بالوصول إلى موقعك.'
                  : 'Please make sure location services are enabled and allow the app to access your location.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            ElevatedButton.icon(
              onPressed: () {
                context.read<PrayerBloc>().add(GetPrayerTimesEvent());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                  horizontal: 24.w,
                  vertical: 12.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getPrayerIcon(int index) {
    switch (index) {
      case 0: // الفجر
        return Icons.nightlight_round;
      case 1: // الشروق
        return Icons.wb_sunny_outlined;
      case 2: // الظهر
        return Icons.wb_sunny;
      case 3: // العصر
        return Icons.wb_twighlight;
      case 4: // المغرب
        return Icons.wb_twilight;
      case 5: // العشاء
        return Icons.nights_stay;
      default:
        return Icons.access_time;
    }
  }

  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}

