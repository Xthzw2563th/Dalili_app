import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/prayer_times/presentation/bloc/prayer_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';

class PrayerTimesWidget extends StatelessWidget {
  const PrayerTimesWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isArabic ? 'أوقات الصلاة' : 'Prayer Times',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () {
                    context.read<PrayerBloc>().add(GetPrayerTimesEvent());
                  },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            BlocBuilder<PrayerBloc, PrayerState>(
              builder: (context, state) {
                if (state is PrayerLoading) {
                  return _buildLoadingState();
                } else if (state is PrayerLoaded) {
                  return _buildLoadedState(context, state);
                } else if (state is PrayerError) {
                  return _buildErrorState(context, state.message);
                } else {
                  // حالة البداية، نطلب أوقات الصلاة
                  context.read<PrayerBloc>().add(GetPrayerTimesEvent());
                  return _buildLoadingState();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Column(
        children: List.generate(
          5,
          (index) => Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 80.w,
                  height: 20.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                ),
                Container(
                  width: 60.w,
                  height: 20.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, PrayerLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    final prayerNames = [
      isArabic ? 'الفجر' : 'Fajr',
      isArabic ? 'الشروق' : 'Sunrise',
      isArabic ? 'الظهر' : 'Dhuhr',
      isArabic ? 'العصر' : 'Asr',
      isArabic ? 'المغرب' : 'Maghrib',
      isArabic ? 'العشاء' : 'Isha',
    ];
    
    final prayerTimes = [
      state.prayerTimes.fajr,
      state.prayerTimes.sunrise,
      state.prayerTimes.dhuhr,
      state.prayerTimes.asr,
      state.prayerTimes.maghrib,
      state.prayerTimes.isha,
    ];
    
    final now = DateTime.now();
    int nextPrayerIndex = 0;
    
    // تحديد الصلاة التالية
    for (int i = 0; i < prayerTimes.length; i++) {
      if (prayerTimes[i].isAfter(now)) {
        nextPrayerIndex = i;
        break;
      }
    }
    
    return Column(
      children: List.generate(
        prayerTimes.length,
        (index) {
          final isNextPrayer = index == nextPrayerIndex;
          
          return Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 8.h,
              ),
              decoration: BoxDecoration(
                color: isNextPrayer
                    ? AppColors.royalBlue.withOpacity(0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(8.r),
                border: isNextPrayer
                    ? Border.all(color: AppColors.royalBlue)
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        _getPrayerIcon(index),
                        color: isNextPrayer
                            ? AppColors.royalBlue
                            : AppColors.lightTextSecondary,
                        size: 20.r,
                      ),
                      SizedBox(width: 8.w),
                      Text(
                        prayerNames[index],
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: isNextPrayer
                                  ? AppColors.royalBlue
                                  : null,
                              fontWeight: isNextPrayer
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                      ),
                    ],
                  ),
                  Text(
                    _formatTime(prayerTimes[index]),
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: isNextPrayer
                              ? AppColors.royalBlue
                              : null,
                          fontWeight: isNextPrayer
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: AppColors.error,
            size: 48.r,
          ),
          SizedBox(height: 16.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyLarge,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 16.h),
          ElevatedButton(
            onPressed: () {
              context.read<PrayerBloc>().add(GetPrayerTimesEvent());
            },
            child: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
          ),
        ],
      ),
    );
  }

  IconData _getPrayerIcon(int index) {
    switch (index) {
      case 0: // الفجر
        return Icons.nightlight_round;
      case 1: // الشروق
        return Icons.wb_sunny_outlined;
      case 2: // الظهر
        return Icons.wb_sunny;
      case 3: // العصر
        return Icons.wb_twighlight;
      case 4: // المغرب
        return Icons.wb_twilight;
      case 5: // العشاء
        return Icons.nights_stay;
      default:
        return Icons.access_time;
    }
  }

  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}

