import 'package:dalili_app/features/prayer_times/domain/entities/prayer_times.dart';
import 'package:dalili_app/features/prayer_times/domain/usecases/get_prayer_times.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// الأحداث
abstract class PrayerEvent extends Equatable {
  const PrayerEvent();

  @override
  List<Object> get props => [];
}

class GetPrayerTimesEvent extends PrayerEvent {}

// الحالات
abstract class PrayerState extends Equatable {
  const PrayerState();

  @override
  List<Object> get props => [];
}

class PrayerInitial extends PrayerState {}

class PrayerLoading extends PrayerState {}

class PrayerLoaded extends PrayerState {
  final PrayerTimes prayerTimes;

  const PrayerLoaded({required this.prayerTimes});

  @override
  List<Object> get props => [prayerTimes];
}

class PrayerError extends PrayerState {
  final String message;

  const PrayerError({required this.message});

  @override
  List<Object> get props => [message];
}

// بلوك
class PrayerBloc extends Bloc<PrayerEvent, PrayerState> {
  final GetPrayerTimes getPrayerTimes;

  PrayerBloc({
    required this.getPrayerTimes,
  }) : super(PrayerInitial()) {
    on<GetPrayerTimesEvent>(_onGetPrayerTimes);
  }

  Future<void> _onGetPrayerTimes(
    GetPrayerTimesEvent event,
    Emitter<PrayerState> emit,
  ) async {
    emit(PrayerLoading());
    
    final result = await getPrayerTimes();
    
    result.fold(
      (failure) => emit(PrayerError(message: failure.message)),
      (prayerTimes) => emit(PrayerLoaded(prayerTimes: prayerTimes)),
    );
  }
}

