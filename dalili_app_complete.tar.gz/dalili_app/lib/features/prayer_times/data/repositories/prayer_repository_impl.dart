import 'dart:convert';

import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/core/network/network_info.dart';
import 'package:dalili_app/features/prayer_times/data/models/prayer_times_model.dart';
import 'package:dalili_app/features/prayer_times/domain/entities/prayer_times.dart';
import 'package:dalili_app/features/prayer_times/domain/repositories/prayer_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:adhan/adhan.dart';

class PrayerRepositoryImpl implements PrayerRepository {
  final NetworkInfo networkInfo;
  final http.Client client;

  PrayerRepositoryImpl({
    required this.networkInfo,
    required this.client,
  });

  @override
  Future<Either<Failure, PrayerTimes>> getPrayerTimes() async {
    if (await networkInfo.isConnected) {
      try {
        // الحصول على الموقع الحالي
        final position = await _determinePosition();
        
        // استخدام مكتبة adhan لحساب أوقات الصلاة
        final coordinates = Coordinates(position.latitude, position.longitude);
        final dateTime = DateTime.now();
        final params = CalculationMethod.umm_al_qura.getParameters();
        params.madhab = Madhab.shafi;
        
        final prayerTimes = PrayerTimesCalculator.calculate(
          coordinates: coordinates,
          date: dateTime,
          calculationParameters: params,
        );
        
        // الحصول على اسم المدينة من خلال العكس الجغرافي
        final cityName = await _getCityName(position.latitude, position.longitude);
        
        // إنشاء نموذج أوقات الصلاة
        final prayerTimesModel = PrayerTimesModel(
          fajr: prayerTimes.fajr,
          sunrise: prayerTimes.sunrise,
          dhuhr: prayerTimes.dhuhr,
          asr: prayerTimes.asr,
          maghrib: prayerTimes.maghrib,
          isha: prayerTimes.isha,
          date: dateTime.toString().split(' ')[0],
          city: cityName,
        );
        
        return Right(prayerTimesModel);
      } on LocationException catch (e) {
        return Left(LocationFailure(message: e.message));
      } on ServerException {
        return Left(ServerFailure());
      } catch (e) {
        return Left(GeneralFailure(message: e.toString()));
      }
    } else {
      return Left(NetworkFailure());
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // التحقق مما إذا كانت خدمات الموقع ممكّنة
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw LocationException(message: 'يرجى تفعيل خدمة الموقع');
    }

    // التحقق من إذن الموقع
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك');
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      throw LocationException(message: 'يرجى السماح بالوصول إلى موقعك من إعدادات الجهاز');
    }

    // الحصول على الموقع الحالي
    return await Geolocator.getCurrentPosition();
  }

  Future<String> _getCityName(double latitude, double longitude) async {
    try {
      final url = 'https://nominatim.openstreetmap.org/reverse?format=json&lat=$latitude&lon=$longitude&zoom=10';
      final response = await client.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final address = data['address'];
        
        // محاولة الحصول على اسم المدينة
        String city = address['city'] ?? 
                      address['town'] ?? 
                      address['village'] ?? 
                      address['county'] ?? 
                      address['state'] ?? 
                      'غير معروف';
        
        return city;
      } else {
        return 'غير معروف';
      }
    } catch (e) {
      return 'غير معروف';
    }
  }
}

