import 'package:equatable/equatable.dart';

class News extends Equatable {
  final String id;
  final String titleAr;
  final String titleEn;
  final String summaryAr;
  final String summaryEn;
  final String contentAr;
  final String contentEn;
  final String imageUrl;
  final String source;
  final String sourceUrl;
  final DateTime publishDate;
  final List<String> categories;

  const News({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.summaryAr,
    required this.summaryEn,
    required this.contentAr,
    required this.contentEn,
    required this.imageUrl,
    required this.source,
    required this.sourceUrl,
    required this.publishDate,
    required this.categories,
  });

  @override
  List<Object> get props => [
        id,
        titleAr,
        titleEn,
        summaryAr,
        summaryEn,
        contentAr,
        contentEn,
        imageUrl,
        source,
        sourceUrl,
        publishDate,
        categories,
      ];
}

