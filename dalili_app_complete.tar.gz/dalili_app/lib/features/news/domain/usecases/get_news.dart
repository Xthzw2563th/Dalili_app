import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/news/domain/entities/news.dart';
import 'package:dalili_app/features/news/domain/repositories/news_repository.dart';
import 'package:dartz/dartz.dart';

class GetNews {
  final NewsRepository repository;

  GetNews(this.repository);

  Future<Either<Failure, List<News>>> call() async {
    return await repository.getNews();
  }
}

