import 'package:dalili_app/features/news/domain/entities/news.dart';

class NewsModel extends News {
  const NewsModel({
    required String id,
    required String titleAr,
    required String titleEn,
    required String summaryAr,
    required String summaryEn,
    required String contentAr,
    required String contentEn,
    required String imageUrl,
    required String source,
    required String sourceUrl,
    required DateTime publishDate,
    required List<String> categories,
  }) : super(
          id: id,
          titleAr: titleAr,
          titleEn: titleEn,
          summaryAr: summaryAr,
          summaryEn: summaryEn,
          contentAr: contentAr,
          contentEn: contentEn,
          imageUrl: imageUrl,
          source: source,
          sourceUrl: sourceUrl,
          publishDate: publishDate,
          categories: categories,
        );

  factory NewsModel.fromJson(Map<String, dynamic> json) {
    return NewsModel(
      id: json['id'],
      titleAr: json['title_ar'],
      titleEn: json['title_en'],
      summaryAr: json['summary_ar'],
      summaryEn: json['summary_en'],
      contentAr: json['content_ar'],
      contentEn: json['content_en'],
      imageUrl: json['image_url'],
      source: json['source'],
      sourceUrl: json['source_url'],
      publishDate: DateTime.parse(json['publish_date']),
      categories: List<String>.from(json['categories']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title_ar': titleAr,
      'title_en': titleEn,
      'summary_ar': summaryAr,
      'summary_en': summaryEn,
      'content_ar': contentAr,
      'content_en': contentEn,
      'image_url': imageUrl,
      'source': source,
      'source_url': sourceUrl,
      'publish_date': publishDate.toIso8601String(),
      'categories': categories,
    };
  }
}

