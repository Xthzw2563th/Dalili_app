import 'dart:convert';

import 'package:dalili_app/core/constants/constants.dart';
import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/core/network/network_info.dart';
import 'package:dalili_app/features/news/data/models/news_model.dart';
import 'package:dalili_app/features/news/domain/entities/news.dart';
import 'package:dalili_app/features/news/domain/repositories/news_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class NewsRepositoryImpl implements NewsRepository {
  final NetworkInfo networkInfo;
  final http.Client client;
  final SharedPreferences sharedPreferences;

  NewsRepositoryImpl({
    required this.networkInfo,
    required this.client,
    required this.sharedPreferences,
  });

  @override
  Future<Either<Failure, List<News>>> getNews() async {
    if (await networkInfo.isConnected) {
      try {
        // في الواقع، يمكن استخدام API للحصول على الأخبار
        // لكن هنا سنستخدم بيانات ثابتة للتبسيط
        final news = _getHardcodedNews();
        
        // حفظ البيانات في التخزين المؤقت
        final jsonString = json.encode(
          news.map((newsItem) => (newsItem as NewsModel).toJson()).toList(),
        );
        
        await sharedPreferences.setString('news', jsonString);
        
        return Right(news);
      } on ServerException {
        return Left(ServerFailure());
      } catch (e) {
        return Left(GeneralFailure(message: e.toString()));
      }
    } else {
      // محاولة استرداد البيانات من التخزين المؤقت
      try {
        final jsonString = sharedPreferences.getString('news');
        
        if (jsonString != null) {
          final jsonList = json.decode(jsonString) as List;
          final news = jsonList
              .map((newsJson) => NewsModel.fromJson(newsJson))
              .toList();
          
          return Right(news);
        } else {
          return Left(CacheFailure());
        }
      } on Exception {
        return Left(CacheFailure());
      }
    }
  }

  List<News> _getHardcodedNews() {
    final now = DateTime.now();
    
    return [
      NewsModel(
        id: '1',
        titleAr: 'إطلاق برنامج جديد لدعم المشاريع الصغيرة في المملكة',
        titleEn: 'New program launched to support small businesses in the Kingdom',
        summaryAr: 'أعلنت وزارة التجارة عن إطلاق برنامج جديد لدعم المشاريع الصغيرة والمتوسطة بقيمة 3 مليارات ريال',
        summaryEn: 'The Ministry of Commerce announced the launch of a new program to support small and medium enterprises worth 3 billion riyals',
        contentAr: 'أعلنت وزارة التجارة اليوم عن إطلاق برنامج جديد لدعم المشاريع الصغيرة والمتوسطة بقيمة 3 مليارات ريال، وذلك ضمن مبادرات رؤية المملكة 2030. ويهدف البرنامج إلى تعزيز نمو المشاريع الصغيرة والمتوسطة وزيادة مساهمتها في الناتج المحلي الإجمالي. وقال وزير التجارة إن البرنامج سيوفر التمويل والدعم الفني والاستشاري للمشاريع الصغيرة والمتوسطة، وسيساهم في خلق فرص عمل جديدة للشباب السعودي.',
        contentEn: 'The Ministry of Commerce announced today the launch of a new program to support small and medium enterprises worth 3 billion riyals, as part of the Kingdom\'s Vision 2030 initiatives. The program aims to enhance the growth of small and medium enterprises and increase their contribution to the GDP. The Minister of Commerce said that the program will provide financing, technical and advisory support to small and medium enterprises, and will contribute to creating new job opportunities for Saudi youth.',
        imageUrl: 'https://example.com/news1.jpg',
        source: 'وزارة التجارة',
        sourceUrl: 'https://mci.gov.sa',
        publishDate: now.subtract(const Duration(hours: 2)),
        categories: ['اقتصاد', 'أعمال'],
      ),
      NewsModel(
        id: '2',
        titleAr: 'افتتاح أكبر مركز ترفيهي في الرياض',
        titleEn: 'Largest entertainment center opens in Riyadh',
        summaryAr: 'افتتحت الهيئة العامة للترفيه أكبر مركز ترفيهي في الرياض بمساحة تتجاوز 100 ألف متر مربع',
        summaryEn: 'The General Entertainment Authority opened the largest entertainment center in Riyadh with an area of more than 100,000 square meters',
        contentAr: 'افتتحت الهيئة العامة للترفيه اليوم أكبر مركز ترفيهي في الرياض بمساحة تتجاوز 100 ألف متر مربع. ويضم المركز العديد من المرافق الترفيهية والألعاب والمطاعم والمقاهي، ويتوقع أن يستقبل أكثر من مليون زائر سنوياً. وقال رئيس الهيئة العامة للترفيه إن افتتاح هذا المركز يأتي ضمن جهود الهيئة لتطوير قطاع الترفيه في المملكة وتوفير خيارات ترفيهية متنوعة للمواطنين والمقيمين.',
        contentEn: 'The General Entertainment Authority opened today the largest entertainment center in Riyadh with an area of more than 100,000 square meters. The center includes many entertainment facilities, games, restaurants and cafes, and is expected to receive more than one million visitors annually. The Chairman of the General Entertainment Authority said that the opening of this center comes within the Authority\'s efforts to develop the entertainment sector in the Kingdom and provide diverse entertainment options for citizens and residents.',
        imageUrl: 'https://example.com/news2.jpg',
        source: 'الهيئة العامة للترفيه',
        sourceUrl: 'https://gea.gov.sa',
        publishDate: now.subtract(const Duration(hours: 5)),
        categories: ['ترفيه', 'سياحة'],
      ),
      NewsModel(
        id: '3',
        titleAr: 'إطلاق مبادرة لزراعة 10 ملايين شجرة في المملكة',
        titleEn: 'Initiative launched to plant 10 million trees in the Kingdom',
        summaryAr: 'أطلقت وزارة البيئة والمياه والزراعة مبادرة لزراعة 10 ملايين شجرة في مختلف مناطق المملكة',
        summaryEn: 'The Ministry of Environment, Water and Agriculture launched an initiative to plant 10 million trees in various regions of the Kingdom',
        contentAr: 'أطلقت وزارة البيئة والمياه والزراعة اليوم مبادرة لزراعة 10 ملايين شجرة في مختلف مناطق المملكة، وذلك ضمن مبادرات السعودية الخضراء. وتهدف المبادرة إلى زيادة الغطاء النباتي ومكافحة التصحر وتحسين جودة الحياة في المدن السعودية. وقال وزير البيئة والمياه والزراعة إن المبادرة ستساهم في تحقيق أهداف رؤية المملكة 2030 في مجال الاستدامة البيئية.',
        contentEn: 'The Ministry of Environment, Water and Agriculture launched today an initiative to plant 10 million trees in various regions of the Kingdom, as part of the Green Saudi initiatives. The initiative aims to increase vegetation cover, combat desertification and improve the quality of life in Saudi cities. The Minister of Environment, Water and Agriculture said that the initiative will contribute to achieving the goals of the Kingdom\'s Vision 2030 in the field of environmental sustainability.',
        imageUrl: 'https://example.com/news3.jpg',
        source: 'وزارة البيئة والمياه والزراعة',
        sourceUrl: 'https://mewa.gov.sa',
        publishDate: now.subtract(const Duration(hours: 8)),
        categories: ['بيئة', 'استدامة'],
      ),
      NewsModel(
        id: '4',
        titleAr: 'إطلاق منصة إلكترونية جديدة للخدمات الحكومية',
        titleEn: 'New electronic platform launched for government services',
        summaryAr: 'أطلقت وزارة الداخلية منصة إلكترونية جديدة تتيح للمواطنين والمقيمين الوصول إلى أكثر من 100 خدمة حكومية',
        summaryEn: 'The Ministry of Interior launched a new electronic platform that allows citizens and residents to access more than 100 government services',
        contentAr: 'أطلقت وزارة الداخلية اليوم منصة إلكترونية جديدة تتيح للمواطنين والمقيمين الوصول إلى أكثر من 100 خدمة حكومية بشكل إلكتروني، وذلك ضمن جهود المملكة للتحول الرقمي. وتهدف المنصة إلى تسهيل الإجراءات الحكومية وتقليل الوقت والجهد المبذول في الحصول على الخدمات. وقال وزير الداخلية إن المنصة ستساهم في تحسين جودة الخدمات الحكومية وتعزيز رضا المستفيدين.',
        contentEn: 'The Ministry of Interior launched today a new electronic platform that allows citizens and residents to access more than 100 government services electronically, as part of the Kingdom\'s efforts for digital transformation. The platform aims to facilitate government procedures and reduce the time and effort spent in obtaining services. The Minister of Interior said that the platform will contribute to improving the quality of government services and enhancing the satisfaction of beneficiaries.',
        imageUrl: 'https://example.com/news4.jpg',
        source: 'وزارة الداخلية',
        sourceUrl: 'https://moi.gov.sa',
        publishDate: now.subtract(const Duration(hours: 12)),
        categories: ['تقنية', 'خدمات حكومية'],
      ),
      NewsModel(
        id: '5',
        titleAr: 'افتتاح أول مصنع للسيارات الكهربائية في المملكة',
        titleEn: 'First electric car factory opens in the Kingdom',
        summaryAr: 'افتتحت وزارة الصناعة والثروة المعدنية أول مصنع للسيارات الكهربائية في المملكة بالشراكة مع شركة عالمية',
        summaryEn: 'The Ministry of Industry and Mineral Resources opened the first electric car factory in the Kingdom in partnership with a global company',
        contentAr: 'افتتحت وزارة الصناعة والثروة المعدنية اليوم أول مصنع للسيارات الكهربائية في المملكة بالشراكة مع شركة عالمية، وذلك ضمن جهود المملكة لتنويع مصادر الدخل وتطوير الصناعة المحلية. ويتوقع أن ينتج المصنع 50 ألف سيارة كهربائية سنوياً، وسيوفر آلاف فرص العمل للشباب السعودي. وقال وزير الصناعة والثروة المعدنية إن افتتاح هذا المصنع يعد خطوة مهمة نحو تحقيق أهداف رؤية المملكة 2030 في مجال الصناعة والاستدامة.',
        contentEn: 'The Ministry of Industry and Mineral Resources opened today the first electric car factory in the Kingdom in partnership with a global company, as part of the Kingdom\'s efforts to diversify income sources and develop local industry. The factory is expected to produce 50,000 electric cars annually, and will provide thousands of job opportunities for Saudi youth. The Minister of Industry and Mineral Resources said that the opening of this factory is an important step towards achieving the goals of the Kingdom\'s Vision 2030 in the field of industry and sustainability.',
        imageUrl: 'https://example.com/news5.jpg',
        source: 'وزارة الصناعة والثروة المعدنية',
        sourceUrl: 'https://mim.gov.sa',
        publishDate: now.subtract(const Duration(days: 1)),
        categories: ['صناعة', 'اقتصاد'],
      ),
    ];
  }
}

