import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/news/presentation/bloc/news_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class NewsWidget extends StatelessWidget {
  const NewsWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isArabic ? 'آخر الأخبار' : 'Latest News',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () {
                    context.read<NewsBloc>().add(GetNewsEvent());
                  },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            BlocBuilder<NewsBloc, NewsState>(
              builder: (context, state) {
                if (state is NewsLoading) {
                  return _buildLoadingState();
                } else if (state is NewsLoaded) {
                  return _buildLoadedState(context, state);
                } else if (state is NewsError) {
                  return _buildErrorState(context, state.message);
                } else {
                  // حالة البداية، نطلب الأخبار
                  context.read<NewsBloc>().add(GetNewsEvent());
                  return _buildLoadingState();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Column(
        children: List.generate(
          2,
          (index) => Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              width: double.infinity,
              height: 100.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, NewsLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    // عرض أول خبرين فقط في الصفحة الرئيسية
    final latestNews = state.news.take(2).toList();
    
    if (latestNews.isEmpty) {
      return Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 16.h),
          child: Text(
            isArabic ? 'لا توجد أخبار متاحة' : 'No news available',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ),
      );
    }
    
    return Column(
      children: List.generate(
        latestNews.length,
        (index) {
          final news = latestNews[index];
          
          return Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: Theme.of(context).dividerTheme.color ?? Colors.grey.withOpacity(0.2),
                ),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(12.r),
                onTap: () {
                  // فتح صفحة تفاصيل الخبر
                },
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.only(
                        topRight: isArabic ? Radius.zero : Radius.circular(12.r),
                        bottomRight: isArabic ? Radius.zero : Radius.circular(12.r),
                        topLeft: isArabic ? Radius.circular(12.r) : Radius.zero,
                        bottomLeft: isArabic ? Radius.circular(12.r) : Radius.zero,
                      ),
                      child: CachedNetworkImage(
                        imageUrl: news.imageUrl,
                        width: 100.w,
                        height: 100.h,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          color: Colors.grey[300],
                          child: Center(
                            child: Icon(
                              Icons.image,
                              color: Colors.grey[400],
                              size: 24.r,
                            ),
                          ),
                        ),
                        errorWidget: (context, url, error) => Container(
                          color: Colors.grey[300],
                          child: Center(
                            child: Icon(
                              Icons.error_outline_rounded,
                              color: Colors.grey[400],
                              size: 24.r,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(12.r),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isArabic ? news.titleAr : news.titleEn,
                              style: Theme.of(context).textTheme.titleMedium,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              isArabic ? news.summaryAr : news.summaryEn,
                              style: Theme.of(context).textTheme.bodySmall,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 8.h),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  news.source,
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                        color: AppColors.royalBlue,
                                      ),
                                ),
                                Text(
                                  _formatDate(news.publishDate, isArabic),
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: AppColors.error,
            size: 32.r,
          ),
          SizedBox(height: 8.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8.h),
          TextButton(
            onPressed: () {
              context.read<NewsBloc>().add(GetNewsEvent());
            },
            child: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date, bool isArabic) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return isArabic
            ? 'منذ ${difference.inMinutes} دقيقة'
            : '${difference.inMinutes} minutes ago';
      } else {
        return isArabic
            ? 'منذ ${difference.inHours} ساعة'
            : '${difference.inHours} hours ago';
      }
    } else if (difference.inDays == 1) {
      return isArabic ? 'الأمس' : 'Yesterday';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}

