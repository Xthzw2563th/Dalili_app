import 'package:dalili_app/features/news/domain/entities/news.dart';
import 'package:dalili_app/features/news/domain/usecases/get_news.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// الأحداث
abstract class NewsEvent extends Equatable {
  const NewsEvent();

  @override
  List<Object> get props => [];
}

class GetNewsEvent extends NewsEvent {}

// الحالات
abstract class NewsState extends Equatable {
  const NewsState();

  @override
  List<Object> get props => [];
}

class NewsInitial extends NewsState {}

class NewsLoading extends NewsState {}

class NewsLoaded extends NewsState {
  final List<News> news;

  const NewsLoaded({required this.news});

  @override
  List<Object> get props => [news];
}

class NewsError extends NewsState {
  final String message;

  const NewsError({required this.message});

  @override
  List<Object> get props => [message];
}

// بلوك
class NewsBloc extends Bloc<NewsEvent, NewsState> {
  final GetNews getNews;

  NewsBloc({
    required this.getNews,
  }) : super(NewsInitial()) {
    on<GetNewsEvent>(_onGetNews);
  }

  Future<void> _onGetNews(
    GetNewsEvent event,
    Emitter<NewsState> emit,
  ) async {
    emit(NewsLoading());
    
    final result = await getNews();
    
    result.fold(
      (failure) => emit(NewsError(message: failure.message)),
      (news) => emit(NewsLoaded(news: news)),
    );
  }
}

