import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/core/utils/app_utils.dart';
import 'package:dalili_app/features/calendar/presentation/bloc/calendar_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:hijri/hijri_calendar.dart';

class CalendarWidget extends StatelessWidget {
  const CalendarWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isArabic ? 'التقويم' : 'Calendar',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () {
                    context.read<CalendarBloc>().add(GetCalendarEventsEvent());
                  },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            _buildCurrentDateInfo(context),
            SizedBox(height: 16.h),
            BlocBuilder<CalendarBloc, CalendarState>(
              builder: (context, state) {
                if (state is CalendarLoading) {
                  return _buildLoadingState();
                } else if (state is CalendarLoaded) {
                  return _buildLoadedState(context, state);
                } else if (state is CalendarError) {
                  return _buildErrorState(context, state.message);
                } else {
                  // حالة البداية، نطلب أحداث التقويم
                  context.read<CalendarBloc>().add(GetCalendarEventsEvent());
                  return _buildLoadingState();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentDateInfo(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    final now = DateTime.now();
    final hijriDate = HijriCalendar.fromDate(now);
    
    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.royalBlue,
            AppColors.turquoise,
          ],
        ),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isArabic ? 'التاريخ الميلادي' : 'Gregorian',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withOpacity(0.8),
                    ),
              ),
              SizedBox(height: 4.h),
              Text(
                isArabic
                    ? AppUtils.formatDateAr(now)
                    : AppUtils.formatDateEn(now),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              SizedBox(height: 4.h),
              Text(
                isArabic
                    ? AppUtils.getDayNameAr(now)
                    : AppUtils.getDayNameEn(now),
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white,
                    ),
              ),
            ],
          ),
          Container(
            height: 50.h,
            width: 1,
            color: Colors.white.withOpacity(0.3),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isArabic ? 'التاريخ الهجري' : 'Hijri',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withOpacity(0.8),
                    ),
              ),
              SizedBox(height: 4.h),
              Text(
                '${hijriDate.hDay} ${isArabic ? AppUtils.convertToHijri(now, showYear: false) : hijriDate.hMonth.toString()} ${hijriDate.hYear}',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              SizedBox(height: 4.h),
              Text(
                isArabic
                    ? hijriDate.dayWeName
                    : hijriDate.dayName,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white,
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Column(
        children: List.generate(
          2,
          (index) => Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              width: double.infinity,
              height: 60.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, CalendarLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    // عرض أول حدثين فقط في الصفحة الرئيسية
    final upcomingEvents = state.calendarEvents.take(2).toList();
    
    if (upcomingEvents.isEmpty) {
      return Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 16.h),
          child: Text(
            isArabic ? 'لا توجد أحداث قادمة' : 'No upcoming events',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ),
      );
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          isArabic ? 'الأحداث القادمة' : 'Upcoming Events',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        SizedBox(height: 8.h),
        ...List.generate(
          upcomingEvents.length,
          (index) {
            final event = upcomingEvents[index];
            
            return Padding(
              padding: EdgeInsets.only(bottom: 8.h),
              child: Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(
                    color: Theme.of(context).dividerTheme.color ?? Colors.grey.withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40.r,
                      height: 40.r,
                      decoration: BoxDecoration(
                        color: _getEventColor(event.type).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      child: Icon(
                        _getEventIcon(event.type),
                        color: _getEventColor(event.type),
                        size: 20.r,
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isArabic ? event.nameAr : event.nameEn,
                            style: Theme.of(context).textTheme.titleMedium,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            isArabic
                                ? AppUtils.formatDateAr(event.date)
                                : AppUtils.formatDateEn(event.date),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 8.w,
                        vertical: 4.h,
                      ),
                      decoration: BoxDecoration(
                        color: _getEventColor(event.type).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4.r),
                      ),
                      child: Text(
                        _getRemainingDays(event.date, isArabic),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: _getEventColor(event.type),
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: AppColors.error,
            size: 32.r,
          ),
          SizedBox(height: 8.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8.h),
          TextButton(
            onPressed: () {
              context.read<CalendarBloc>().add(GetCalendarEventsEvent());
            },
            child: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
          ),
        ],
      ),
    );
  }

  Color _getEventColor(String type) {
    switch (type) {
      case 'national':
        return AppColors.royalBlue;
      case 'religious':
        return AppColors.success;
      case 'academic':
        return AppColors.warning;
      case 'holiday':
        return AppColors.info;
      default:
        return AppColors.royalBlue;
    }
  }

  IconData _getEventIcon(String type) {
    switch (type) {
      case 'national':
        return Icons.flag_rounded;
      case 'religious':
        return Icons.mosque_rounded;
      case 'academic':
        return Icons.school_rounded;
      case 'holiday':
        return Icons.celebration_rounded;
      default:
        return Icons.event_rounded;
    }
  }

  String _getRemainingDays(DateTime date, bool isArabic) {
    final now = DateTime.now();
    final difference = date.difference(now).inDays;
    
    if (difference == 0) {
      return isArabic ? 'اليوم' : 'Today';
    } else if (difference == 1) {
      return isArabic ? 'غداً' : 'Tomorrow';
    } else {
      return isArabic ? 'بعد $difference يوم' : 'In $difference days';
    }
  }
}

