import 'package:dalili_app/features/calendar/domain/entities/calendar_event.dart';
import 'package:dalili_app/features/calendar/domain/usecases/get_calendar_events.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// الأحداث
abstract class CalendarEvent extends Equatable {
  const CalendarEvent();

  @override
  List<Object> get props => [];
}

class GetCalendarEventsEvent extends CalendarEvent {}

// الحالات
abstract class CalendarState extends Equatable {
  const CalendarState();

  @override
  List<Object> get props => [];
}

class CalendarInitial extends CalendarState {}

class CalendarLoading extends CalendarState {}

class CalendarLoaded extends CalendarState {
  final List<CalendarEvent> calendarEvents;

  const CalendarLoaded({required this.calendarEvents});

  @override
  List<Object> get props => [calendarEvents];
}

class CalendarError extends CalendarState {
  final String message;

  const CalendarError({required this.message});

  @override
  List<Object> get props => [message];
}

// بلوك
class CalendarBloc extends Bloc<CalendarEvent, CalendarState> {
  final GetCalendarEvents getCalendarEvents;

  CalendarBloc({
    required this.getCalendarEvents,
  }) : super(CalendarInitial()) {
    on<GetCalendarEventsEvent>(_onGetCalendarEvents);
  }

  Future<void> _onGetCalendarEvents(
    GetCalendarEventsEvent event,
    Emitter<CalendarState> emit,
  ) async {
    emit(CalendarLoading());
    
    final result = await getCalendarEvents();
    
    result.fold(
      (failure) => emit(CalendarError(message: failure.message)),
      (calendarEvents) => emit(CalendarLoaded(calendarEvents: calendarEvents)),
    );
  }
}

