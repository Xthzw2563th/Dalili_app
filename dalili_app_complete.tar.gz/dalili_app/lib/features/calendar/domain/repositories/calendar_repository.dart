import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/calendar/domain/entities/calendar_event.dart';
import 'package:dartz/dartz.dart';

abstract class CalendarRepository {
  Future<Either<Failure, List<CalendarEvent>>> getCalendarEvents();
}

