import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/calendar/domain/entities/calendar_event.dart';
import 'package:dalili_app/features/calendar/domain/repositories/calendar_repository.dart';
import 'package:dartz/dartz.dart';

class GetCalendarEvents {
  final CalendarRepository repository;

  GetCalendarEvents(this.repository);

  Future<Either<Failure, List<CalendarEvent>>> call() async {
    return await repository.getCalendarEvents();
  }
}

