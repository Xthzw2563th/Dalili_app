import 'package:equatable/equatable.dart';

class CalendarEvent extends Equatable {
  final String id;
  final String type;
  final String nameAr;
  final String nameEn;
  final DateTime date;
  final String description;
  final bool isHoliday;

  const CalendarEvent({
    required this.id,
    required this.type,
    required this.nameAr,
    required this.nameEn,
    required this.date,
    required this.description,
    required this.isHoliday,
  });

  @override
  List<Object> get props => [
        id,
        type,
        nameAr,
        nameEn,
        date,
        description,
        isHoliday,
      ];
}

