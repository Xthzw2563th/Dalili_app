import 'package:dalili_app/features/calendar/domain/entities/calendar_event.dart';

class CalendarEventModel extends CalendarEvent {
  const CalendarEventModel({
    required String id,
    required String type,
    required String nameAr,
    required String nameEn,
    required DateTime date,
    required String description,
    required bool isHoliday,
  }) : super(
          id: id,
          type: type,
          nameAr: nameAr,
          nameEn: nameEn,
          date: date,
          description: description,
          isHoliday: isHoliday,
        );

  factory CalendarEventModel.fromJson(Map<String, dynamic> json) {
    return CalendarEventModel(
      id: json['id'],
      type: json['type'],
      nameAr: json['name_ar'],
      nameEn: json['name_en'],
      date: DateTime.parse(json['date']),
      description: json['description'],
      isHoliday: json['is_holiday'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'name_ar': nameAr,
      'name_en': nameEn,
      'date': date.toIso8601String(),
      'description': description,
      'is_holiday': isHoliday,
    };
  }
}

