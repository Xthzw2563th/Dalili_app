import 'dart:convert';

import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/core/network/network_info.dart';
import 'package:dalili_app/features/calendar/data/models/calendar_event_model.dart';
import 'package:dalili_app/features/calendar/domain/entities/calendar_event.dart';
import 'package:dalili_app/features/calendar/domain/repositories/calendar_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class CalendarRepositoryImpl implements CalendarRepository {
  final NetworkInfo networkInfo;
  final http.Client client;
  final SharedPreferences sharedPreferences;

  CalendarRepositoryImpl({
    required this.networkInfo,
    required this.client,
    required this.sharedPreferences,
  });

  @override
  Future<Either<Failure, List<CalendarEvent>>> getCalendarEvents() async {
    if (await networkInfo.isConnected) {
      try {
        // في الواقع، يمكن استخدام API للحصول على الأحداث
        // لكن هنا سنستخدم بيانات ثابتة للتبسيط
        final events = _getHardcodedEvents();
        
        // حفظ البيانات في التخزين المؤقت
        final jsonString = json.encode(
          events.map((event) => (event as CalendarEventModel).toJson()).toList(),
        );
        
        await sharedPreferences.setString('calendar_events', jsonString);
        
        return Right(events);
      } on ServerException {
        return Left(ServerFailure());
      } catch (e) {
        return Left(GeneralFailure(message: e.toString()));
      }
    } else {
      // محاولة استرداد البيانات من التخزين المؤقت
      try {
        final jsonString = sharedPreferences.getString('calendar_events');
        
        if (jsonString != null) {
          final jsonList = json.decode(jsonString) as List;
          final events = jsonList
              .map((eventJson) => CalendarEventModel.fromJson(eventJson))
              .toList();
          
          return Right(events);
        } else {
          return Left(CacheFailure());
        }
      } on Exception {
        return Left(CacheFailure());
      }
    }
  }

  List<CalendarEvent> _getHardcodedEvents() {
    final now = DateTime.now();
    final currentYear = now.year;
    
    return [
      // الأعياد الوطنية
      CalendarEventModel(
        id: 'national_day',
        type: 'national',
        nameAr: 'اليوم الوطني',
        nameEn: 'National Day',
        date: DateTime(currentYear, 9, 23),
        description: 'ذكرى توحيد المملكة العربية السعودية',
        isHoliday: true,
      ),
      CalendarEventModel(
        id: 'founding_day',
        type: 'national',
        nameAr: 'يوم التأسيس',
        nameEn: 'Founding Day',
        date: DateTime(currentYear, 2, 22),
        description: 'ذكرى تأسيس الدولة السعودية الأولى',
        isHoliday: true,
      ),
      
      // الأعياد الدينية (تواريخ تقريبية لأنها تعتمد على التقويم الهجري)
      CalendarEventModel(
        id: 'eid_al_fitr',
        type: 'religious',
        nameAr: 'عيد الفطر',
        nameEn: 'Eid Al-Fitr',
        date: DateTime(currentYear, 4, 10), // تقريبي
        description: 'عيد الفطر المبارك',
        isHoliday: true,
      ),
      CalendarEventModel(
        id: 'eid_al_adha',
        type: 'religious',
        nameAr: 'عيد الأضحى',
        nameEn: 'Eid Al-Adha',
        date: DateTime(currentYear, 6, 17), // تقريبي
        description: 'عيد الأضحى المبارك',
        isHoliday: true,
      ),
      CalendarEventModel(
        id: 'ramadan',
        type: 'religious',
        nameAr: 'شهر رمضان',
        nameEn: 'Ramadan',
        date: DateTime(currentYear, 3, 11), // تقريبي
        description: 'شهر رمضان المبارك',
        isHoliday: false,
      ),
      
      // المناسبات الأكاديمية
      CalendarEventModel(
        id: 'school_start',
        type: 'academic',
        nameAr: 'بداية العام الدراسي',
        nameEn: 'School Year Start',
        date: DateTime(currentYear, 9, 1),
        description: 'بداية العام الدراسي الجديد',
        isHoliday: false,
      ),
      CalendarEventModel(
        id: 'school_end',
        type: 'academic',
        nameAr: 'نهاية العام الدراسي',
        nameEn: 'School Year End',
        date: DateTime(currentYear, 6, 30),
        description: 'نهاية العام الدراسي',
        isHoliday: false,
      ),
      CalendarEventModel(
        id: 'mid_year_vacation',
        type: 'academic',
        nameAr: 'إجازة منتصف العام',
        nameEn: 'Mid-Year Vacation',
        date: DateTime(currentYear, 1, 15),
        description: 'إجازة منتصف العام الدراسي',
        isHoliday: true,
      ),
      
      // العطل الرسمية الأخرى
      CalendarEventModel(
        id: 'new_year',
        type: 'holiday',
        nameAr: 'رأس السنة الميلادية',
        nameEn: 'New Year',
        date: DateTime(currentYear, 1, 1),
        description: 'بداية السنة الميلادية الجديدة',
        isHoliday: false,
      ),
    ];
  }
}

