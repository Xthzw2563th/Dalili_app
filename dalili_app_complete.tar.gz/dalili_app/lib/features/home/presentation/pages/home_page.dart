import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/calendar/presentation/pages/calendar_page.dart';
import 'package:dalili_app/features/countdown/presentation/pages/countdown_page.dart';
import 'package:dalili_app/features/home/presentation/widgets/home_dashboard.dart';
import 'package:dalili_app/features/links/presentation/pages/links_page.dart';
import 'package:dalili_app/features/news/presentation/pages/news_page.dart';
import 'package:dalili_app/features/prayer_times/presentation/pages/prayer_times_page.dart';
import 'package:dalili_app/features/qibla/presentation/pages/qibla_page.dart';
import 'package:dalili_app/features/settings/presentation/pages/settings_page.dart';
import 'package:dalili_app/features/weather/presentation/pages/weather_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  
  final List<Widget> _pages = [
    const HomeDashboard(),
    const PrayerTimesPage(),
    const CountdownPage(),
    const CalendarPage(),
    const MoreOptionsPage(),
  ];
  
  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: _pages[_currentIndex],
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, -5),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            child: BottomNavigationBar(
              currentIndex: _currentIndex,
              onTap: (index) {
                setState(() {
                  _currentIndex = index;
                });
              },
              type: BottomNavigationBarType.fixed,
              backgroundColor: Theme.of(context).bottomNavigationBarTheme.backgroundColor,
              selectedItemColor: AppColors.royalBlue,
              unselectedItemColor: AppColors.lightTextSecondary,
              selectedLabelStyle: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12.sp,
              ),
              unselectedLabelStyle: TextStyle(
                fontSize: 12.sp,
              ),
              items: [
                BottomNavigationBarItem(
                  icon: const Icon(Icons.home_rounded),
                  label: isArabic ? 'الرئيسية' : 'Home',
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.access_time_rounded),
                  label: isArabic ? 'الصلاة' : 'Prayer',
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.timer_rounded),
                  label: isArabic ? 'العد التنازلي' : 'Countdown',
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.calendar_today_rounded),
                  label: isArabic ? 'التقويم' : 'Calendar',
                ),
                BottomNavigationBarItem(
                  icon: const Icon(Icons.menu_rounded),
                  label: isArabic ? 'المزيد' : 'More',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MoreOptionsPage extends StatelessWidget {
  const MoreOptionsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'المزيد من الخدمات' : 'More Services'),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.r),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16.r,
          mainAxisSpacing: 16.r,
          children: [
            _buildGridItem(
              context,
              icon: Icons.cloud_rounded,
              title: isArabic ? 'الطقس' : 'Weather',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const WeatherPage()),
                );
              },
            ),
            _buildGridItem(
              context,
              icon: Icons.explore_rounded,
              title: isArabic ? 'القبلة' : 'Qibla',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const QiblaPage()),
                );
              },
            ),
            _buildGridItem(
              context,
              icon: Icons.newspaper_rounded,
              title: isArabic ? 'الأخبار' : 'News',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NewsPage()),
                );
              },
            ),
            _buildGridItem(
              context,
              icon: Icons.link_rounded,
              title: isArabic ? 'روابط مهمة' : 'Important Links',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LinksPage()),
                );
              },
            ),
            _buildGridItem(
              context,
              icon: Icons.settings_rounded,
              title: isArabic ? 'الإعدادات' : 'Settings',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SettingsPage()),
                );
              },
            ),
            _buildGridItem(
              context,
              icon: Icons.info_rounded,
              title: isArabic ? 'عن التطبيق' : 'About',
              onTap: () {
                _showAboutDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGridItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16.r),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardTheme.color,
          borderRadius: BorderRadius.circular(16.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 48.r,
              color: AppColors.royalBlue,
            ),
            SizedBox(height: 12.h),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context, listen: false);
    final isArabic = !settingsProvider.isEnglish;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isArabic ? 'عن التطبيق' : 'About App'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isArabic ? 'دليلي - تطبيق سعودي ذكي شامل' : 'Dalili - Smart Saudi Comprehensive App',
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic
                  ? 'تطبيق سعودي متكامل يخدم المستخدمين في كل جوانب حياتهم اليومية، من مواعيد الرواتب والدعم، إلى أوقات الصلاة والقبلة، بتصميم نظيف، ذكي، وواجهة فخمة.'
                  : 'An integrated Saudi application that serves users in all aspects of their daily lives, from salary and support dates, to prayer times and qibla, with a clean, smart design and a luxurious interface.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic ? 'الإصدار: 1.0.0' : 'Version: 1.0.0',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(isArabic ? 'إغلاق' : 'Close'),
          ),
        ],
      ),
    );
  }
}

