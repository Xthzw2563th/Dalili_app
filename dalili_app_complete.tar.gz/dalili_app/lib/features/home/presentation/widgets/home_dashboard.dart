import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/calendar/presentation/widgets/calendar_widget.dart';
import 'package:dalili_app/features/countdown/presentation/widgets/countdown_widget.dart';
import 'package:dalili_app/features/prayer_times/presentation/widgets/prayer_times_widget.dart';
import 'package:dalili_app/features/weather/presentation/widgets/weather_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({Key? key}) : super(key: key);

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverAppBar(
              expandedHeight: 120.h,
              floating: true,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                title: Text(
                  isArabic ? 'دليلي' : 'Dalili',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppColors.royalBlue,
                        AppColors.turquoise,
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  onPressed: () {
                    // عرض الإشعارات
                  },
                ),
                IconButton(
                  icon: Icon(
                    settingsProvider.isDarkMode
                        ? Icons.light_mode_outlined
                        : Icons.dark_mode_outlined,
                  ),
                  onPressed: () {
                    settingsProvider.toggleDarkMode();
                  },
                ),
              ],
            ),
            SliverPadding(
              padding: EdgeInsets.all(16.r),
              sliver: AnimationLimiter(
                child: SliverList(
                  delegate: SliverChildListDelegate(
                    [
                      AnimationConfiguration.staggeredList(
                        position: 0,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: _buildWelcomeCard(context),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                      AnimationConfiguration.staggeredList(
                        position: 1,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: const PrayerTimesWidget(),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                      AnimationConfiguration.staggeredList(
                        position: 2,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: const CountdownWidget(),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                      AnimationConfiguration.staggeredList(
                        position: 3,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: const WeatherWidget(),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                      AnimationConfiguration.staggeredList(
                        position: 4,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: const CalendarWidget(),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                      AnimationConfiguration.staggeredList(
                        position: 5,
                        duration: const Duration(milliseconds: 500),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: _buildQuickLinksCard(context),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.h),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeCard(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24.r,
                  backgroundColor: AppColors.royalBlue,
                  child: Icon(
                    Icons.person,
                    color: Colors.white,
                    size: 24.r,
                  ),
                ),
                SizedBox(width: 12.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? 'مرحباً بك' : 'Welcome',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      isArabic ? 'نتمنى لك يوماً سعيداً' : 'Have a nice day',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 16.h),
            Text(
              isArabic
                  ? 'دليلي - تطبيق سعودي ذكي شامل يخدم المستخدمين في كل جوانب حياتهم اليومية.'
                  : 'Dalili - A smart Saudi comprehensive app that serves users in all aspects of their daily lives.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickLinksCard(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isArabic ? 'روابط سريعة' : 'Quick Links',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 16.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildQuickLinkItem(
                  context,
                  icon: Icons.qr_code_scanner_rounded,
                  title: 'توكلنا',
                  onTap: () {
                    // فتح تطبيق توكلنا
                  },
                ),
                _buildQuickLinkItem(
                  context,
                  icon: Icons.school_rounded,
                  title: 'مدرستي',
                  onTap: () {
                    // فتح تطبيق مدرستي
                  },
                ),
                _buildQuickLinkItem(
                  context,
                  icon: Icons.account_balance_rounded,
                  title: 'أبشر',
                  onTap: () {
                    // فتح تطبيق أبشر
                  },
                ),
                _buildQuickLinkItem(
                  context,
                  icon: Icons.local_hospital_rounded,
                  title: 'صحتي',
                  onTap: () {
                    // فتح تطبيق صحتي
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickLinkItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Column(
        children: [
          Container(
            width: 50.r,
            height: 50.r,
            decoration: BoxDecoration(
              color: AppColors.royalBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(
              icon,
              color: AppColors.royalBlue,
              size: 24.r,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            title,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

