import 'dart:convert';

import 'package:dalili_app/core/constants/constants.dart';
import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/countdown/data/models/countdown_model.dart';
import 'package:dalili_app/features/countdown/domain/entities/countdown.dart';
import 'package:dalili_app/features/countdown/domain/repositories/countdown_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CountdownRepositoryImpl implements CountdownRepository {
  final SharedPreferences sharedPreferences;

  CountdownRepositoryImpl({
    required this.sharedPreferences,
  });

  @override
  Future<Either<Failure, List<Countdown>>> getCountdownDates() async {
    try {
      final now = DateTime.now();
      final List<CountdownModel> countdownDates = [];
      
      // إضافة تواريخ الرواتب والدعم
      
      // راتب الموظف
      final employeeSalaryDay = AppConstants.salaryDays['موظف'] ?? 27;
      DateTime employeeSalaryDate;
      
      if (now.day > employeeSalaryDay) {
        // الراتب القادم في الشهر التالي
        employeeSalaryDate = DateTime(now.year, now.month + 1, employeeSalaryDay);
      } else {
        // الراتب القادم في هذا الشهر
        employeeSalaryDate = DateTime(now.year, now.month, employeeSalaryDay);
      }
      
      countdownDates.add(
        CountdownModel(
          type: 'salary',
          nameAr: 'راتب الموظف',
          nameEn: 'Employee Salary',
          date: employeeSalaryDate,
          description: 'موعد صرف راتب الموظفين الحكوميين',
        ),
      );
      
      // راتب المتقاعد
      final retirementSalaryDay = AppConstants.salaryDays['متقاعد'] ?? 20;
      DateTime retirementSalaryDate;
      
      if (now.day > retirementSalaryDay) {
        retirementSalaryDate = DateTime(now.year, now.month + 1, retirementSalaryDay);
      } else {
        retirementSalaryDate = DateTime(now.year, now.month, retirementSalaryDay);
      }
      
      countdownDates.add(
        CountdownModel(
          type: 'retirement',
          nameAr: 'راتب المتقاعد',
          nameEn: 'Retirement Salary',
          date: retirementSalaryDate,
          description: 'موعد صرف راتب المتقاعدين',
        ),
      );
      
      // الضمان الاجتماعي
      final socialInsuranceDay = AppConstants.salaryDays['ضمان'] ?? 10;
      DateTime socialInsuranceDate;
      
      if (now.day > socialInsuranceDay) {
        socialInsuranceDate = DateTime(now.year, now.month + 1, socialInsuranceDay);
      } else {
        socialInsuranceDate = DateTime(now.year, now.month, socialInsuranceDay);
      }
      
      countdownDates.add(
        CountdownModel(
          type: 'social_insurance',
          nameAr: 'الضمان الاجتماعي',
          nameEn: 'Social Insurance',
          date: socialInsuranceDate,
          description: 'موعد صرف مستحقات الضمان الاجتماعي',
        ),
      );
      
      // حساب المواطن
      final citizenAccountDay = AppConstants.salaryDays['حساب_المواطن'] ?? 10;
      DateTime citizenAccountDate;
      
      if (now.day > citizenAccountDay) {
        citizenAccountDate = DateTime(now.year, now.month + 1, citizenAccountDay);
      } else {
        citizenAccountDate = DateTime(now.year, now.month, citizenAccountDay);
      }
      
      countdownDates.add(
        CountdownModel(
          type: 'citizen_account',
          nameAr: 'حساب المواطن',
          nameEn: 'Citizen Account',
          date: citizenAccountDate,
          description: 'موعد إيداع دعم حساب المواطن',
        ),
      );
      
      // الدعم السكني
      final housingSupportDay = AppConstants.salaryDays['دعم_سكني'] ?? 15;
      DateTime housingSupportDate;
      
      if (now.day > housingSupportDay) {
        housingSupportDate = DateTime(now.year, now.month + 1, housingSupportDay);
      } else {
        housingSupportDate = DateTime(now.year, now.month, housingSupportDay);
      }
      
      countdownDates.add(
        CountdownModel(
          type: 'housing_support',
          nameAr: 'الدعم السكني',
          nameEn: 'Housing Support',
          date: housingSupportDate,
          description: 'موعد إيداع الدعم السكني',
        ),
      );
      
      // ترتيب التواريخ حسب الأقرب
      countdownDates.sort((a, b) => a.date.compareTo(b.date));
      
      // حفظ التواريخ في التخزين المؤقت
      final jsonString = json.encode(
        countdownDates.map((countdown) => countdown.toJson()).toList(),
      );
      
      await sharedPreferences.setString('countdown_dates', jsonString);
      
      return Right(countdownDates);
    } on Exception {
      return Left(CacheFailure());
    }
  }
}

