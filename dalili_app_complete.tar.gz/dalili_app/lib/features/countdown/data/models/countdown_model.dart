import 'package:dalili_app/features/countdown/domain/entities/countdown.dart';

class CountdownModel extends Countdown {
  const CountdownModel({
    required String type,
    required String nameAr,
    required String nameEn,
    required DateTime date,
    required String description,
  }) : super(
          type: type,
          nameAr: nameAr,
          nameEn: nameEn,
          date: date,
          description: description,
        );

  factory CountdownModel.fromJson(Map<String, dynamic> json) {
    return CountdownModel(
      type: json['type'],
      nameAr: json['name_ar'],
      nameEn: json['name_en'],
      date: DateTime.parse(json['date']),
      description: json['description'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'name_ar': nameAr,
      'name_en': nameEn,
      'date': date.toIso8601String(),
      'description': description,
    };
  }
}

