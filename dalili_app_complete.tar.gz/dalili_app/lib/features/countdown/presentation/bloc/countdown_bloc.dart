import 'package:dalili_app/features/countdown/domain/entities/countdown.dart';
import 'package:dalili_app/features/countdown/domain/usecases/get_countdown_dates.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// الأحداث
abstract class CountdownEvent extends Equatable {
  const CountdownEvent();

  @override
  List<Object> get props => [];
}

class GetCountdownDatesEvent extends CountdownEvent {}

// الحالات
abstract class CountdownState extends Equatable {
  const CountdownState();

  @override
  List<Object> get props => [];
}

class CountdownInitial extends CountdownState {}

class CountdownLoading extends CountdownState {}

class CountdownLoaded extends CountdownState {
  final List<Countdown> countdownDates;

  const CountdownLoaded({required this.countdownDates});

  @override
  List<Object> get props => [countdownDates];
}

class CountdownError extends CountdownState {
  final String message;

  const CountdownError({required this.message});

  @override
  List<Object> get props => [message];
}

// بلوك
class CountdownBloc extends Bloc<CountdownEvent, CountdownState> {
  final GetCountdownDates getCountdownDates;

  CountdownBloc({
    required this.getCountdownDates,
  }) : super(CountdownInitial()) {
    on<GetCountdownDatesEvent>(_onGetCountdownDates);
  }

  Future<void> _onGetCountdownDates(
    GetCountdownDatesEvent event,
    Emitter<CountdownState> emit,
  ) async {
    emit(CountdownLoading());
    
    final result = await getCountdownDates();
    
    result.fold(
      (failure) => emit(CountdownError(message: failure.message)),
      (countdownDates) => emit(CountdownLoaded(countdownDates: countdownDates)),
    );
  }
}

