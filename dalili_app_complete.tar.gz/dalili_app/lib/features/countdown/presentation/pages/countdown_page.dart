import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/countdown/presentation/bloc/countdown_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';
import 'package:lottie/lottie.dart';

class CountdownPage extends StatelessWidget {
  const CountdownPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'العد التنازلي' : 'Countdown'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              context.read<CountdownBloc>().add(GetCountdownDatesEvent());
            },
          ),
        ],
      ),
      body: BlocBuilder<CountdownBloc, CountdownState>(
        builder: (context, state) {
          if (state is CountdownLoading) {
            return _buildLoadingState();
          } else if (state is CountdownLoaded) {
            return _buildLoadedState(context, state);
          } else if (state is CountdownError) {
            return _buildErrorState(context, state.message);
          } else {
            // حالة البداية، نطلب تواريخ العد التنازلي
            context.read<CountdownBloc>().add(GetCountdownDatesEvent());
            return _buildLoadingState();
          }
        },
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 200.w,
              height: 30.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4.r),
              ),
            ),
            SizedBox(height: 16.h),
            Expanded(
              child: ListView.builder(
                itemCount: 5,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.only(bottom: 16.h),
                    child: Container(
                      width: double.infinity,
                      height: 120.h,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.r),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, CountdownLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Padding(
      padding: EdgeInsets.all(16.r),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'مواعيد الرواتب والدعم' : 'Salary & Support Dates',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          SizedBox(height: 8.h),
          Text(
            isArabic
                ? 'عد تنازلي دقيق لمواعيد الرواتب والدعم الحكومي'
                : 'Accurate countdown for salary and government support dates',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          SizedBox(height: 24.h),
          Expanded(
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemCount: state.countdownDates.length,
              itemBuilder: (context, index) {
                final countdown = state.countdownDates[index];
                
                return Padding(
                  padding: EdgeInsets.only(bottom: 16.h),
                  child: Container(
                    padding: EdgeInsets.all(16.r),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardTheme.color,
                      borderRadius: BorderRadius.circular(16.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 56.r,
                              height: 56.r,
                              decoration: BoxDecoration(
                                color: _getCountdownColor(countdown.type).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(16.r),
                              ),
                              child: Icon(
                                _getCountdownIcon(countdown.type),
                                color: _getCountdownColor(countdown.type),
                                size: 28.r,
                              ),
                            ),
                            SizedBox(width: 16.w),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    isArabic ? countdown.nameAr : countdown.nameEn,
                                    style: Theme.of(context).textTheme.titleLarge,
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    countdown.date.toString().split(' ')[0],
                                    style: Theme.of(context).textTheme.bodyMedium,
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    countdown.description,
                                    style: Theme.of(context).textTheme.bodySmall,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 16.h),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(
                            horizontal: 16.w,
                            vertical: 12.h,
                          ),
                          decoration: BoxDecoration(
                            color: _getCountdownColor(countdown.type).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          child: CountdownTimer(
                            endTime: countdown.date.millisecondsSinceEpoch,
                            widgetBuilder: (_, time) {
                              if (time == null) {
                                return Center(
                                  child: Text(
                                    isArabic ? 'تم الصرف' : 'Disbursed',
                                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                          color: _getCountdownColor(countdown.type),
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                );
                              }
                              
                              return Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  _buildTimeUnit(
                                    context,
                                    value: time.days ?? 0,
                                    unit: isArabic ? 'يوم' : 'Days',
                                    color: _getCountdownColor(countdown.type),
                                  ),
                                  _buildTimeUnit(
                                    context,
                                    value: time.hours ?? 0,
                                    unit: isArabic ? 'ساعة' : 'Hours',
                                    color: _getCountdownColor(countdown.type),
                                  ),
                                  _buildTimeUnit(
                                    context,
                                    value: time.min ?? 0,
                                    unit: isArabic ? 'دقيقة' : 'Minutes',
                                    color: _getCountdownColor(countdown.type),
                                  ),
                                  _buildTimeUnit(
                                    context,
                                    value: time.sec ?? 0,
                                    unit: isArabic ? 'ثانية' : 'Seconds',
                                    color: _getCountdownColor(countdown.type),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeUnit(
    BuildContext context, {
    required int value,
    required String unit,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          width: 60.r,
          height: 60.r,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.2),
                blurRadius: 5,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: Text(
              value.toString().padLeft(2, '0'),
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: color,
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ),
        ),
        SizedBox(height: 8.h),
        Text(
          unit,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.network(
              'https://assets3.lottiefiles.com/packages/lf20_ysrn2iwp.json',
              width: 200.r,
              height: 200.r,
            ),
            SizedBox(height: 24.h),
            Text(
              message,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            ElevatedButton.icon(
              onPressed: () {
                context.read<CountdownBloc>().add(GetCountdownDatesEvent());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                  horizontal: 24.w,
                  vertical: 12.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getCountdownColor(String type) {
    switch (type) {
      case 'salary':
        return AppColors.success;
      case 'citizen_account':
        return AppColors.info;
      case 'social_insurance':
        return AppColors.warning;
      case 'housing_support':
        return AppColors.royalBlue;
      case 'retirement':
        return AppColors.turquoise;
      default:
        return AppColors.royalBlue;
    }
  }

  IconData _getCountdownIcon(String type) {
    switch (type) {
      case 'salary':
        return Icons.account_balance_wallet_rounded;
      case 'citizen_account':
        return Icons.account_balance_rounded;
      case 'social_insurance':
        return Icons.security_rounded;
      case 'housing_support':
        return Icons.home_rounded;
      case 'retirement':
        return Icons.chair_rounded;
      default:
        return Icons.calendar_today_rounded;
    }
  }
}

