import 'package:dalili_app/core/theme/app_theme.dart';
import 'package:dalili_app/features/countdown/presentation/bloc/countdown_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:dalili_app/features/settings/presentation/providers/settings_provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';

class CountdownWidget extends StatelessWidget {
  const CountdownWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isArabic ? 'العد التنازلي' : 'Countdown',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () {
                    context.read<CountdownBloc>().add(GetCountdownDatesEvent());
                  },
                ),
              ],
            ),
            SizedBox(height: 16.h),
            BlocBuilder<CountdownBloc, CountdownState>(
              builder: (context, state) {
                if (state is CountdownLoading) {
                  return _buildLoadingState();
                } else if (state is CountdownLoaded) {
                  return _buildLoadedState(context, state);
                } else if (state is CountdownError) {
                  return _buildErrorState(context, state.message);
                } else {
                  // حالة البداية، نطلب تواريخ العد التنازلي
                  context.read<CountdownBloc>().add(GetCountdownDatesEvent());
                  return _buildLoadingState();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Column(
        children: List.generate(
          3,
          (index) => Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              width: double.infinity,
              height: 80.h,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.r),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadedState(BuildContext context, CountdownLoaded state) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    // عرض أول 3 تواريخ فقط في الصفحة الرئيسية
    final countdownDates = state.countdownDates.take(3).toList();
    
    return Column(
      children: List.generate(
        countdownDates.length,
        (index) {
          final countdown = countdownDates[index];
          
          return Padding(
            padding: EdgeInsets.only(bottom: 12.h),
            child: Container(
              padding: EdgeInsets.all(12.r),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: Theme.of(context).dividerTheme.color ?? Colors.grey.withOpacity(0.2),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48.r,
                    height: 48.r,
                    decoration: BoxDecoration(
                      color: _getCountdownColor(countdown.type).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Icon(
                      _getCountdownIcon(countdown.type),
                      color: _getCountdownColor(countdown.type),
                      size: 24.r,
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? countdown.nameAr : countdown.nameEn,
                          style: Theme.of(context).textTheme.titleLarge,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          countdown.date.toString().split(' ')[0],
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 8.w),
                  CountdownTimer(
                    endTime: countdown.date.millisecondsSinceEpoch,
                    widgetBuilder: (_, time) {
                      if (time == null) {
                        return Text(
                          isArabic ? 'انتهى' : 'Ended',
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                color: AppColors.error,
                                fontWeight: FontWeight.bold,
                              ),
                        );
                      }
                      
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            isArabic ? 'متبقي' : 'Remaining',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            '${time.days ?? 0}d ${time.hours ?? 0}h ${time.min ?? 0}m',
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                  color: _getCountdownColor(countdown.type),
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String message) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final isArabic = !settingsProvider.isEnglish;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: AppColors.error,
            size: 48.r,
          ),
          SizedBox(height: 16.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyLarge,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 16.h),
          ElevatedButton(
            onPressed: () {
              context.read<CountdownBloc>().add(GetCountdownDatesEvent());
            },
            child: Text(isArabic ? 'إعادة المحاولة' : 'Try Again'),
          ),
        ],
      ),
    );
  }

  Color _getCountdownColor(String type) {
    switch (type) {
      case 'salary':
        return AppColors.success;
      case 'citizen_account':
        return AppColors.info;
      case 'social_insurance':
        return AppColors.warning;
      case 'housing_support':
        return AppColors.royalBlue;
      case 'retirement':
        return AppColors.turquoise;
      default:
        return AppColors.royalBlue;
    }
  }

  IconData _getCountdownIcon(String type) {
    switch (type) {
      case 'salary':
        return Icons.account_balance_wallet_rounded;
      case 'citizen_account':
        return Icons.account_balance_rounded;
      case 'social_insurance':
        return Icons.security_rounded;
      case 'housing_support':
        return Icons.home_rounded;
      case 'retirement':
        return Icons.chair_rounded;
      default:
        return Icons.calendar_today_rounded;
    }
  }
}

