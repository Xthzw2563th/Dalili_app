import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/countdown/domain/entities/countdown.dart';
import 'package:dartz/dartz.dart';

abstract class CountdownRepository {
  Future<Either<Failure, List<Countdown>>> getCountdownDates();
}

