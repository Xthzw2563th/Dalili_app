import 'package:equatable/equatable.dart';

class Countdown extends Equatable {
  final String type;
  final String nameAr;
  final String nameEn;
  final DateTime date;
  final String description;

  const Countdown({
    required this.type,
    required this.nameAr,
    required this.nameEn,
    required this.date,
    required this.description,
  });

  @override
  List<Object> get props => [
        type,
        nameAr,
        nameEn,
        date,
        description,
      ];
}

