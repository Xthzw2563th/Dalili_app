import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/countdown/domain/entities/countdown.dart';
import 'package:dalili_app/features/countdown/domain/repositories/countdown_repository.dart';
import 'package:dartz/dartz.dart';

class GetCountdownDates {
  final CountdownRepository repository;

  GetCountdownDates(this.repository);

  Future<Either<Failure, List<Countdown>>> call() async {
    return await repository.getCountdownDates();
  }
}

