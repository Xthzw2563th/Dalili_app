import 'package:dalili_app/features/settings/domain/usecases/get_settings.dart';
import 'package:dalili_app/features/settings/domain/usecases/update_settings.dart';
import 'package:flutter/material.dart';

class SettingsProvider extends ChangeNotifier {
  final GetSettings getSettings;
  final UpdateSettings updateSettings;

  SettingsProvider({
    required this.getSettings,
    required this.updateSettings,
  }) {
    _loadSettings();
  }

  bool _isDarkMode = false;
  bool _isEnglish = false;
  bool _showPrayerNotifications = true;
  bool _showCountdownNotifications = true;
  bool _showNewsNotifications = false;
  bool _isPremium = false;

  bool get isDarkMode => _isDarkMode;
  bool get isEnglish => _isEnglish;
  bool get showPrayerNotifications => _showPrayerNotifications;
  bool get showCountdownNotifications => _showCountdownNotifications;
  bool get showNewsNotifications => _showNewsNotifications;
  bool get isPremium => _isPremium;

  Future<void> _loadSettings() async {
    final settingsEither = await getSettings();
    settingsEither.fold(
      (failure) {
        // استخدام القيم الافتراضية في حالة الفشل
      },
      (settings) {
        _isDarkMode = settings.isDarkMode;
        _isEnglish = settings.isEnglish;
        _showPrayerNotifications = settings.showPrayerNotifications;
        _showCountdownNotifications = settings.showCountdownNotifications;
        _showNewsNotifications = settings.showNewsNotifications;
        _isPremium = settings.isPremium;
        notifyListeners();
      },
    );
  }

  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> toggleLanguage() async {
    _isEnglish = !_isEnglish;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> togglePrayerNotifications() async {
    _showPrayerNotifications = !_showPrayerNotifications;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> toggleCountdownNotifications() async {
    _showCountdownNotifications = !_showCountdownNotifications;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> toggleNewsNotifications() async {
    _showNewsNotifications = !_showNewsNotifications;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> setPremium(bool value) async {
    _isPremium = value;
    notifyListeners();
    await _saveSettings();
  }

  Future<void> _saveSettings() async {
    final params = UpdateSettingsParams(
      isDarkMode: _isDarkMode,
      isEnglish: _isEnglish,
      showPrayerNotifications: _showPrayerNotifications,
      showCountdownNotifications: _showCountdownNotifications,
      showNewsNotifications: _showNewsNotifications,
      isPremium: _isPremium,
    );
    
    await updateSettings(params);
  }
}

