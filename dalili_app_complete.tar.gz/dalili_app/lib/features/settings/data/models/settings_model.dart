import 'package:dalili_app/features/settings/domain/entities/settings.dart';

class SettingsModel extends Settings {
  const SettingsModel({
    required bool isDarkMode,
    required bool isEnglish,
    required bool showPrayerNotifications,
    required bool showCountdownNotifications,
    required bool showNewsNotifications,
    required bool isPremium,
  }) : super(
          isDarkMode: isDarkMode,
          isEnglish: isEnglish,
          showPrayerNotifications: showPrayerNotifications,
          showCountdownNotifications: showCountdownNotifications,
          showNewsNotifications: showNewsNotifications,
          isPremium: isPremium,
        );

  factory SettingsModel.fromJson(Map<String, dynamic> json) {
    return SettingsModel(
      isDarkMode: json['is_dark_mode'] ?? false,
      isEnglish: json['is_english'] ?? false,
      showPrayerNotifications: json['show_prayer_notifications'] ?? true,
      showCountdownNotifications: json['show_countdown_notifications'] ?? true,
      showNewsNotifications: json['show_news_notifications'] ?? false,
      isPremium: json['is_premium'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'is_dark_mode': isDarkMode,
      'is_english': isEnglish,
      'show_prayer_notifications': showPrayerNotifications,
      'show_countdown_notifications': showCountdownNotifications,
      'show_news_notifications': showNewsNotifications,
      'is_premium': isPremium,
    };
  }

  factory SettingsModel.defaultSettings() {
    return const SettingsModel(
      isDarkMode: false,
      isEnglish: false,
      showPrayerNotifications: true,
      showCountdownNotifications: true,
      showNewsNotifications: false,
      isPremium: false,
    );
  }
}

