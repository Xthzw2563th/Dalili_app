import 'dart:convert';

import 'package:dalili_app/core/constants/constants.dart';
import 'package:dalili_app/core/errors/exceptions.dart';
import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/settings/data/models/settings_model.dart';
import 'package:dalili_app/features/settings/domain/entities/settings.dart';
import 'package:dalili_app/features/settings/domain/repositories/settings_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  final SharedPreferences sharedPreferences;

  SettingsRepositoryImpl({
    required this.sharedPreferences,
  });

  @override
  Future<Either<Failure, Settings>> getSettings() async {
    try {
      final jsonString = sharedPreferences.getString('settings');
      
      if (jsonString != null) {
        final jsonMap = json.decode(jsonString) as Map<String, dynamic>;
        return Right(SettingsModel.fromJson(jsonMap));
      } else {
        // إذا لم يتم العثور على إعدادات، استخدم الإعدادات الافتراضية
        final defaultSettings = SettingsModel.defaultSettings();
        
        // حفظ الإعدادات الافتراضية
        await sharedPreferences.setString(
          'settings',
          json.encode(defaultSettings.toJson()),
        );
        
        return Right(defaultSettings);
      }
    } on Exception {
      return Left(CacheFailure());
    }
  }

  @override
  Future<Either<Failure, bool>> updateSettings({
    required bool isDarkMode,
    required bool isEnglish,
    required bool showPrayerNotifications,
    required bool showCountdownNotifications,
    required bool showNewsNotifications,
    required bool isPremium,
  }) async {
    try {
      final settings = SettingsModel(
        isDarkMode: isDarkMode,
        isEnglish: isEnglish,
        showPrayerNotifications: showPrayerNotifications,
        showCountdownNotifications: showCountdownNotifications,
        showNewsNotifications: showNewsNotifications,
        isPremium: isPremium,
      );
      
      final jsonString = json.encode(settings.toJson());
      
      await sharedPreferences.setString('settings', jsonString);
      
      // حفظ القيم الفردية أيضًا للوصول السريع
      await sharedPreferences.setBool(AppConstants.prefIsDarkMode, isDarkMode);
      await sharedPreferences.setBool(AppConstants.prefIsEnglish, isEnglish);
      await sharedPreferences.setBool(AppConstants.prefShowPrayerNotifications, showPrayerNotifications);
      await sharedPreferences.setBool(AppConstants.prefShowCountdownNotifications, showCountdownNotifications);
      await sharedPreferences.setBool(AppConstants.prefShowNewsNotifications, showNewsNotifications);
      await sharedPreferences.setBool(AppConstants.prefIsPremium, isPremium);
      
      return const Right(true);
    } on Exception {
      return Left(CacheFailure());
    }
  }
}

