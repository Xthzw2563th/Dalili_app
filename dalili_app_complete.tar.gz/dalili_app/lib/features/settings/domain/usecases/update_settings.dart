import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/settings/domain/repositories/settings_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

class UpdateSettings {
  final SettingsRepository repository;

  UpdateSettings(this.repository);

  Future<Either<Failure, bool>> call(UpdateSettingsParams params) async {
    return await repository.updateSettings(
      isDarkMode: params.isDarkMode,
      isEnglish: params.isEnglish,
      showPrayerNotifications: params.showPrayerNotifications,
      showCountdownNotifications: params.showCountdownNotifications,
      showNewsNotifications: params.showNewsNotifications,
      isPremium: params.isPremium,
    );
  }
}

class UpdateSettingsParams extends Equatable {
  final bool isDarkMode;
  final bool isEnglish;
  final bool showPrayerNotifications;
  final bool showCountdownNotifications;
  final bool showNewsNotifications;
  final bool isPremium;

  const UpdateSettingsParams({
    required this.isDarkMode,
    required this.isEnglish,
    required this.showPrayerNotifications,
    required this.showCountdownNotifications,
    required this.showNewsNotifications,
    required this.isPremium,
  });

  @override
  List<Object> get props => [
        isDarkMode,
        isEnglish,
        showPrayerNotifications,
        showCountdownNotifications,
        showNewsNotifications,
        isPremium,
      ];
}

