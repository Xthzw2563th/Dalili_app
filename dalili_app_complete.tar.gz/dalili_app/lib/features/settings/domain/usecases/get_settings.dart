import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/settings/domain/entities/settings.dart';
import 'package:dalili_app/features/settings/domain/repositories/settings_repository.dart';
import 'package:dartz/dartz.dart';

class GetSettings {
  final SettingsRepository repository;

  GetSettings(this.repository);

  Future<Either<Failure, Settings>> call() async {
    return await repository.getSettings();
  }
}

