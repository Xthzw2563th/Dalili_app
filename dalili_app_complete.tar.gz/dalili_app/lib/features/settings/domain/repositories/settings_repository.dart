import 'package:dalili_app/core/errors/failures.dart';
import 'package:dalili_app/features/settings/domain/entities/settings.dart';
import 'package:dartz/dartz.dart';

abstract class SettingsRepository {
  Future<Either<Failure, Settings>> getSettings();
  
  Future<Either<Failure, bool>> updateSettings({
    required bool isDarkMode,
    required bool isEnglish,
    required bool showPrayerNotifications,
    required bool showCountdownNotifications,
    required bool showNewsNotifications,
    required bool isPremium,
  });
}

