import 'package:equatable/equatable.dart';

class Settings extends Equatable {
  final bool isDarkMode;
  final bool isEnglish;
  final bool showPrayerNotifications;
  final bool showCountdownNotifications;
  final bool showNewsNotifications;
  final bool isPremium;

  const Settings({
    required this.isDarkMode,
    required this.isEnglish,
    required this.showPrayerNotifications,
    required this.showCountdownNotifications,
    required this.showNewsNotifications,
    required this.isPremium,
  });

  @override
  List<Object> get props => [
        isDarkMode,
        isEnglish,
        showPrayerNotifications,
        showCountdownNotifications,
        showNewsNotifications,
        isPremium,
      ];
}

